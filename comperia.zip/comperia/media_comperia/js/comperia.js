function openWindowComperia(link) {
	form = window.open(link, '', 'width=950,height=700,status=no,scrollbars=yes');
	form.focus();
	return false;
} 