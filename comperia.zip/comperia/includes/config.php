<?php
// Konfiguracja bazy danych
define('DB_HOST', 'localhost');
define('DB_NAME', 'comperia_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Ustawienia aplikacji
define('SITE_NAME', 'Comperia - Panel Administracyjny');
define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/comperia');

// Konfiguracja API Comperia
define('COMPERIA_API_BASE_URL', 'https://www.autoplan24.pl/api/');
// Klucz API Comperia
define('COMPERIA_API_KEY', 'a96c5b91c85f15c7c7');

// Ustawienia sesji
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));

// Ustawienia błędów
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Funkcja autoloadująca klasy
spl_autoload_register(function ($class_name) {
    // Sprawdź czy to klasa ComperiaAPI
    if ($class_name === 'ComperiaAPI') {
        require_once __DIR__ . '/ComperiaAPI.php';
        return;
    }
    
    // Standardowe ładowanie klas
    $file = __DIR__ . '/classes/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Inicjalizacja połączenia z API Comperia
$comperiaAPI = new ComperiaAPI(COMPERIA_API_KEY);

/**
 * Pobiera instancję API Comperia
 * @return ComperiaAPI Instancja klasy ComperiaAPI
 */
function getComperiaAPI() {
    global $comperiaAPI;
    return $comperiaAPI;
}
