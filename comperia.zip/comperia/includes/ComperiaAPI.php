<?php
/**
 * Klasa do obsługi API Comperia
 */
class ComperiaAPI {
    /**
     * Adres bazowy API Comperia
     * @var string
     */
    private $apiBaseUrl = 'https://www.autoplan24.pl/api/';
    
    /**
     * Klucz API do autoryzacji
     * @var string
     */
    private $apiKey;
    
    /**
     * Konstruktor klasy
     * 
     * @param string $apiKey Klucz API do autoryzacji
     */
    public function __construct($apiKey) {
        $this->apiKey = $apiKey;
    }
    
    /**
     * Wykonuje żądanie do API
     * 
     * @param string $endpoint Endpoint API
     * @param string $method Metoda HTTP (GET, POST, PUT, DELETE)
     * @param array $data Dane do wysłania
     * @return array Odpowiedź z API
     * @throws Exception W przypadku błędu żądania
     */
    private function makeRequest($endpoint, $method = 'GET', $data = []) {
        $url = $this->apiBaseUrl . ltrim($endpoint, '/');
        $ch = curl_init();
        
        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Content-Type: application/json',
            'Accept: application/json'
        ];
        
        $options = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 30,
        ];
        
        if ($method === 'POST') {
            $options[CURLOPT_POST] = true;
            $options[CURLOPT_POSTFIELDS] = json_encode($data);
        } elseif ($method === 'PUT') {
            $options[CURLOPT_CUSTOMREQUEST] = 'PUT';
            $options[CURLOPT_POSTFIELDS] = json_encode($data);
        } elseif ($method === 'DELETE') {
            $options[CURLOPT_CUSTOMREQUEST] = 'DELETE';
        }
        
        curl_setopt_array($ch, $options);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($error) {
            throw new Exception("Błąd połączenia z API Comperia: " . $error);
        }
        
        $decodedResponse = json_decode($response, true);
        
        if ($httpCode >= 400) {
            $errorMessage = isset($decodedResponse['message']) ? $decodedResponse['message'] : 'Nieznany błąd API';
            throw new Exception("Błąd API ({$httpCode}): " . $errorMessage);
        }
        
        return $decodedResponse;
    }
    
    /**
     * Pobiera listę produktów
     * 
     * @param array $params Parametry filtrowania i stronicowania
     * @return array Lista produktów
     */
    public function getProducts($params = []) {
        $query = !empty($params) ? '?' . http_build_query($params) : '';
        return $this->makeRequest('products' . $query);
    }
    
    /**
     * Pobiera szczegóły produktu
     * 
     * @param int $productId ID produktu
     * @return array Szczegóły produktu
     */
    public function getProductDetails($productId) {
        return $this->makeRequest('products/' . $productId);
    }
    
    /**
     * Aktualizuje dane produktu
     * 
     * @param int $productId ID produktu do aktualizacji
     * @param array $data Dane do aktualizacji
     * @return array Odpowiedź z API
     */
    public function updateProduct($productId, $data) {
        return $this->makeRequest('products/' . $productId, 'PUT', $data);
    }
    
    /**
     * Tworzy nowy produkt
     * 
     * @param array $data Dane produktu do utworzenia
     * @return array Odpowiedź z API
     */
    public function createProduct($data) {
        return $this->makeRequest('products', 'POST', $data);
    }
    
    /**
     * Zmienia status produktu
     * 
     * @param int $productId ID produktu
     * @param string $status Nowy status (np. 'publish', 'draft', 'trash')
     * @return array Odpowiedź z API
     */
    public function updateProductStatus($productId, $status) {
        return $this->makeRequest('products/' . $productId . '/status', 'PUT', ['status' => $status]);
    }
    
    /**
     * Pobiera listę kategorii produktów
     * 
     * @return array Lista kategorii
     */
    public function getCategories() {
        return $this->makeRequest('categories');
    }
}
