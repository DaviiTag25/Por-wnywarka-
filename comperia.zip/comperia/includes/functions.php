<?php
// Funkcja do przekierowań
function redirect($url) {
    header("Location: " . SITE_URL . "/" . ltrim($url, '/'));
    exit();
}

// Funkcja do zabezpieczania danych wejściowych
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Funkcja do sprawdzania uprawnień użytkownika
function checkPermission($requiredRole) {
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== $requiredRole) {
        $_SESSION['error'] = "Nie masz uprawnień do przeglądania tej strony.";
        redirect('index.php');
    }
}

// Funkcja do wyświetlania komunikatów
function displayMessage() {
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-success">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
    }
    if (isset($_SESSION['error'])) {
        echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
        unset($_SESSION['error']);
    }
}

// Funkcja do generowania tokena CSRF
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Funkcja do weryfikacji tokena CSRF
function verifyCSRFToken($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    return true;
}
