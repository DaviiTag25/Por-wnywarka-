<?php
/**
 * Funkcje użytkowe dla aplikacji Comperia
 */

// Funkcja do formatowania ceny
function formatPrice($price, $currency = 'PLN') {
    return number_format($price, 2, ',', ' ') . ' ' . $currency;
}

// Funkcja do formatowania daty
function formatDate($date, $format = 'Y-m-d H:i') {
    if (!$date) return '-';
    $timestamp = is_numeric($date) ? $date : strtotime($date);
    return date($format, $timestamp);
}

// Funkcja do skracania tekstu
function truncateText($text, $length = 100, $suffix = '...') {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . $suffix;
}

// Funkcja do generowania sluga
function generateSlug($text) {
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    $text = trim($text, '-');
    return $text;
}

// Funkcja do walidacji emaila
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Funkcja do walidacji numeru telefonu (polski format)
function isValidPhone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    return preg_match('/^[0-9]{9}$/', $phone) || preg_match('/^[0-9]{11}$/', $phone);
}

// Funkcja do generowania unikalnego ID
function generateUniqueId($prefix = '') {
    return $prefix . uniqid() . '_' . time();
}

// Funkcja do tworzenia paginacji
function createPagination($totalItems, $itemsPerPage, $currentPage, $urlPattern = '?page=$page') {
    $totalPages = ceil($totalItems / $itemsPerPage);
    $pagination = [];
    
    // Poprzednia strona
    if ($currentPage > 1) {
        $pagination[] = [
            'type' => 'prev',
            'url' => str_replace('$page', $currentPage - 1, $urlPattern),
            'label' => 'Poprzednia'
        ];
    }
    
    // Strony
    $startPage = max(1, $currentPage - 2);
    $endPage = min($totalPages, $currentPage + 2);
    
    if ($startPage > 1) {
        $pagination[] = [
            'type' => 'page',
            'url' => str_replace('$page', 1, $urlPattern),
            'label' => 1,
            'active' => false
        ];
        if ($startPage > 2) {
            $pagination[] = ['type' => 'ellipsis'];
        }
    }
    
    for ($i = $startPage; $i <= $endPage; $i++) {
        $pagination[] = [
            'type' => 'page',
            'url' => str_replace('$page', $i, $urlPattern),
            'label' => $i,
            'active' => $i == $currentPage
        ];
    }
    
    if ($endPage < $totalPages) {
        if ($endPage < $totalPages - 1) {
            $pagination[] = ['type' => 'ellipsis'];
        }
        $pagination[] = [
            'type' => 'page',
            'url' => str_replace('$page', $totalPages, $urlPattern),
            'label' => $totalPages,
            'active' => false
        ];
    }
    
    // Następna strona
    if ($currentPage < $totalPages) {
        $pagination[] = [
            'type' => 'next',
            'url' => str_replace('$page', $currentPage + 1, $urlPattern),
            'label' => 'Następna'
        ];
    }
    
    return $pagination;
}

// Funkcja do renderowania paginacji w HTML
function renderPagination($pagination) {
    if (empty($pagination)) return '';
    
    $html = '<nav aria-label="Paginacja"><ul class="pagination justify-content-center">';
    
    foreach ($pagination as $item) {
        $classes = ['page-item'];
        
        if ($item['type'] === 'ellipsis') {
            $html .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
        } elseif ($item['type'] === 'page' && isset($item['active']) && $item['active']) {
            $classes[] = 'active';
            $html .= '<li class="' . implode(' ', $classes) . '"><span class="page-link">' . $item['label'] . '</span></li>';
        } else {
            $html .= '<li class="' . implode(' ', $classes) . '"><a class="page-link" href="' . htmlspecialchars($item['url']) . '">' . $item['label'] . '</a></li>';
        }
    }
    
    $html .= '</ul></nav>';
    
    return $html;
}

// Funkcja do przesyłania pliku
function uploadFile($file, $targetDir, $allowedTypes = [], $maxSize = 5242880) {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return ['success' => false, 'error' => 'Nieprawidłowy plik'];
    }
    
    // Sprawdzenie rozmiaru
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'error' => 'Plik jest zbyt duży'];
    }
    
    // Sprawdzenie typu
    if (!empty($allowedTypes)) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, $allowedTypes)) {
            return ['success' => false, 'error' => 'Nieprawidłowy typ pliku'];
        }
    }
    
    // Utworzenie katalogu docelowego
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    // Generowanie unikalnej nazwy pliku
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '.' . $extension;
    $targetPath = $targetDir . '/' . $filename;
    
    // Przesłanie pliku
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => true, 'filename' => $filename, 'path' => $targetPath];
    }
    
    return ['success' => false, 'error' => 'Błąd podczas przesyłania pliku'];
}

// Funkcja do tworzenia miniaturek obrazów
function createThumbnail($sourcePath, $targetPath, $width = 300, $height = 300) {
    if (!file_exists($sourcePath)) {
        return false;
    }
    
    $imageInfo = getimagesize($sourcePath);
    if (!$imageInfo) {
        return false;
    }
    
    list($sourceWidth, $sourceHeight, $imageType) = $imageInfo;
    
    // Obliczanie proporcji
    $ratio = min($width / $sourceWidth, $height / $sourceHeight);
    $newWidth = intval($sourceWidth * $ratio);
    $newHeight = intval($sourceHeight * $ratio);
    
    // Tworzenie obrazu źródłowego
    switch ($imageType) {
        case IMAGETYPE_JPEG:
            $source = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $source = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $source = imagecreatefromgif($sourcePath);
            break;
        default:
            return false;
    }
    
    // Tworzenie obrazu docelowego
    $target = imagecreatetruecolor($newWidth, $newHeight);
    
    // Przezroczystość dla PNG
    if ($imageType == IMAGETYPE_PNG) {
        imagealphablending($target, false);
        imagesavealpha($target, true);
        $transparent = imagecolorallocatealpha($target, 255, 255, 255, 127);
        imagefilledrectangle($target, 0, 0, $newWidth, $newHeight, $transparent);
    }
    
    // Skalowanie obrazu
    imagecopyresampled($target, $source, 0, 0, 0, 0, $newWidth, $newHeight, $sourceWidth, $sourceHeight);
    
    // Zapis obrazu
    $result = false;
    switch ($imageType) {
        case IMAGETYPE_JPEG:
            $result = imagejpeg($target, $targetPath, 90);
            break;
        case IMAGETYPE_PNG:
            $result = imagepng($target, $targetPath, 9);
            break;
        case IMAGETYPE_GIF:
            $result = imagegif($target, $targetPath);
            break;
    }
    
    // Zwolnienie pamięci
    imagedestroy($source);
    imagedestroy($target);
    
    return $result;
}

// Funkcja do czyszczenia tekstu z tagów HTML
function cleanText($text) {
    return strip_tags(trim($text));
}

// Funkcja do generowania kodu HTML dla statusu
function getStatusBadge($status) {
    $classes = [
        'publish' => 'badge bg-success',
        'draft' => 'badge bg-warning',
        'trash' => 'badge bg-danger',
        'pending' => 'badge bg-info',
        'private' => 'badge bg-secondary'
    ];
    
    $labels = [
        'publish' => 'Opublikowany',
        'draft' => 'Szkic',
        'trash' => 'W koszu',
        'pending' => 'Oczekujący',
        'private' => 'Prywatny'
    ];
    
    $class = $classes[$status] ?? 'badge bg-secondary';
    $label = $labels[$status] ?? ucfirst($status);
    
    return '<span class="' . $class . '">' . $label . '</span>';
}

// Funkcja do logowania błędów
function logError($message, $context = []) {
    $logMessage = date('Y-m-d H:i:s') . ' - ' . $message;
    if (!empty($context)) {
        $logMessage .= ' Context: ' . json_encode($context);
    }
    error_log($logMessage);
}

// Funkcja do sprawdzania, czy żądanie jest AJAX
function isAjaxRequest() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}
?>
