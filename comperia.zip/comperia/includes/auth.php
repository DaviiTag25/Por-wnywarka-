<?php
/**
 * Funkcje autentykacji i autoryzacji
 */

// Funkcja do logowania użytkownika
function login($email, $password) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            // Zaktualizuj ostatnie logowanie
            $updateStmt = $db->prepare("UPDATE users SET updated_at = NOW() WHERE id = ?");
            $updateStmt->execute([$user['id']]);
            
            // Ustaw sesję
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            
            // Zaloguj akcję
            logAction($user['id'], 'login', 'Użytkownik zalogowany', $_SERVER['REMOTE_ADDR']);
            
            return true;
        }
        
        return false;
    } catch (PDOException $e) {
        error_log("Błąd logowania: " . $e->getMessage());
        return false;
    }
}

// Funkcja do sprawdzania, czy użytkownik jest zalogowany
function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

// Funkcja do sprawdzania, czy użytkownik ma określoną rolę
function hasRole($role) {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
}

// Funkcja do sprawdzania, czy użytkownik jest administratorem
function isAdmin() {
    return hasRole('admin');
}

// Funkcja do wymuszania logowania (jeśli nie zalogowany, przekieruj do logowania)
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = 'Musisz być zalogowany, aby uzyskać dostęp do tej strony.';
        header('Location: login.php');
        exit();
    }
}

// Funkcja do wymuszania roli administratora
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        $_SESSION['error'] = 'Nie masz uprawnień administratora.';
        header('Location: index.php');
        exit();
    }
}

// Funkcja do wylogowania
function logout() {
    if (isLoggedIn()) {
        logAction($_SESSION['user_id'], 'logout', 'Użytkownik wylogowany', $_SERVER['REMOTE_ADDR']);
    }
    
    // Zniszcz sesję
    session_unset();
    session_destroy();
    
    // Usuń ciasteczka sesji
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    header('Location: login.php');
    exit();
}

// Funkcja do zmiany hasła
function changePassword($userId, $currentPassword, $newPassword) {
    global $db;
    
    try {
        // Sprawdź obecne hasło
        $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($currentPassword, $user['password'])) {
            return false;
        }
        
        // Zmień hasło
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $db->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
        $result = $updateStmt->execute([$hashedPassword, $userId]);
        
        if ($result) {
            logAction($userId, 'password_change', 'Hasło zostało zmienione', $_SERVER['REMOTE_ADDR']);
        }
        
        return $result;
    } catch (PDOException $e) {
        error_log("Błąd zmiany hasła: " . $e->getMessage());
        return false;
    }
}

// Funkcja do resetowania hasła
function resetPassword($email) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT id, email FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return false;
        }
        
        // Generuj losowe hasło
        $newPassword = generateRandomPassword();
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        // Zapisz nowe hasło
        $updateStmt = $db->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
        $result = $updateStmt->execute([$hashedPassword, $user['id']]);
        
        if ($result) {
            // Wyślij email z nowym hasłem (tutaj można dodać funkcję wysyłającą email)
            logAction($user['id'], 'password_reset', 'Hasło zostało zresetowane', $_SERVER['REMOTE_ADDR']);
            
            // W tym miejscu można dodać kod wysyłający email
            // sendPasswordResetEmail($email, $newPassword);
            
            return $newPassword; // Zwróć hasło do wyświetlenia (tylko do celów deweloperskich)
        }
        
        return false;
    } catch (PDOException $e) {
        error_log("Błąd resetowania hasła: " . $e->getMessage());
        return false;
    }
}

// Funkcja pomocnicza do generowania losowego hasła
function generateRandomPassword($length = 12) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

// Funkcja do logowania akcji
function logAction($userId, $action, $details = '', $ipAddress = '') {
    global $db;
    
    try {
        $stmt = $db->prepare("INSERT INTO logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$userId, $action, $details, $ipAddress]);
    } catch (PDOException $e) {
        error_log("Błąd logowania akcji: " . $e->getMessage());
    }
}

// Funkcja do pobierania historii logowań użytkownika
function getUserLoginHistory($userId, $limit = 10) {
    global $db;
    
    try {
        $stmt = $db->prepare("
            SELECT action, details, ip_address, created_at 
            FROM logs 
            WHERE user_id = ? AND action IN ('login', 'logout', 'password_change', 'password_reset')
            ORDER BY created_at DESC 
            LIMIT ?
        ");
        $stmt->execute([$userId, $limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Błąd pobierania historii: " . $e->getMessage());
        return [];
    }
}

// Funkcja do sprawdzania, czy konto jest aktywne
function isAccountActive($userId) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT status FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        return $user && $user['status'] === 'active';
    } catch (PDOException $e) {
        error_log("Błąd sprawdzania statusu konta: " . $e->getMessage());
        return false;
    }
}
?>
