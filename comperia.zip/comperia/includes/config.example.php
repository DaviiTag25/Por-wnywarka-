<?php
// Przykładowy plik konfiguracyjny
// Skopiuj ten plik jako config.local.php i ustaw właściwe wartości

// Konfiguracja bazy danych
define('DB_HOST', 'localhost');
define('DB_NAME', 'comperia_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Konfiguracja API Comperia
define('COMPERIA_API_BASE_URL', 'https://www.autoplan24.pl/api/');
define('COMPERIA_API_KEY', 'tutaj_wprowadz_swoj_klucz_api');

// Ustawienia aplikacji
define('SITE_NAME', 'Autoplan24 - Panel Administracyjny');
define('SITE_URL', 'https://' . $_SERVER['HTTP_HOST']);
define('BASE_PATH', '/');

// Ustawienia sesji
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));

// Ustawienia błędów
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Funkcja autoloadująca klasy
spl_autoload_register(function ($class_name) {
    // Sprawdź czy to klasa ComperiaAPI
    if ($class_name === 'ComperiaAPI') {
        require_once __DIR__ . '/ComperiaAPI.php';
        return;
    }
    
    // Standardowe ładowanie klas
    $file = __DIR__ . '/classes/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Inicjalizacja połączenia z API Comperia
$comperiaAPI = new ComperiaAPI(COMPERIA_API_KEY);

/**
 * Pobiera instancję API Comperia
 * @return ComperiaAPI Instancja klasy ComperiaAPI
 */
function getComperiaAPI() {
    global $comperiaAPI;
    return $comperiaAPI;
}

// Flaga informująca, że aplikacja jest zainstalowana
define('APP_INSTALLED', true);
?>
