// Główny plik JavaScript dla aplikacji Comperia

document.addEventListener('DOMContentLoaded', function() {
    // Obsługa zaznaczania wszystkich checkboxów
    const selectAllCheckbox = document.getElementById('selectAll');
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('input[type="checkbox"][name="product_ids[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });
        
        // Sprawdzanie, czy wszystkie checkboxy są zaznaczone
        const checkboxes = document.querySelectorAll('input[type="checkbox"][name="product_ids[]"]');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const allChecked = Array.from(checkboxes).every(cb => cb.checked);
                selectAllCheckbox.checked = allChecked;
            });
        });
    }
    
    // Obsługa potwierdzeń dla akcji usuwania
    const deleteButtons = document.querySelectorAll('a[onclick*="confirm"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm') || 'Czy na pewno chcesz wykonać tę operację?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });
    
    // Automatyczne ukrywanie alertów po 5 sekundach
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(function() {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.remove();
            }, 500);
        }, 5000);
    });
    
    // Obsługa formularzy AJAX
    const ajaxForms = document.querySelectorAll('form[data-ajax="true"]');
    ajaxForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitButton = this.querySelector('button[type="submit"]');
            
            // Zablokuj przycisk
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Przetwarzanie...';
            
            fetch(this.action, {
                method: this.method,
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Pokaż komunikat sukcesu
                    showAlert(data.message || 'Operacja wykonana pomyślnie', 'success');
                    
                    // Jeśli formularz ma atrybut data-redirect, przekieruj
                    if (this.dataset.redirect) {
                        setTimeout(() => {
                            window.location.href = this.dataset.redirect;
                        }, 1500);
                    }
                } else {
                    showAlert(data.message || 'Wystąpił błąd', 'danger');
                }
            })
            .catch(error => {
                showAlert('Wystąpił błąd podczas przetwarzania żądania', 'danger');
                console.error('Błąd:', error);
            })
            .finally(() => {
                // Odblokuj przycisk
                submitButton.disabled = false;
                submitButton.innerHTML = submitButton.getAttribute('data-original-text') || 'Zapisz';
            });
        });
    });
    
    // Funkcja do wyświetlania alertów
    function showAlert(message, type = 'info') {
        const alertContainer = document.getElementById('alert-container') || document.querySelector('.container-fluid');
        
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        alertContainer.insertBefore(alert, alertContainer.firstChild);
        
        // Automatyczne ukrywanie po 5 sekundach
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 500);
        }, 5000);
    }
    
    // Inicjalizacja tooltipów Bootstrap
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Obsługa podglądu obrazków
    const imagePreviews = document.querySelectorAll('input[type="file"][accept*="image"]');
    imagePreviews.forEach(input => {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById(input.dataset.preview) || document.querySelector('.image-preview');
                    if (preview) {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    });
});

// Funkcja do formatowania waluty
function formatCurrency(amount, currency = 'PLN') {
    return new Intl.NumberFormat('pl-PL', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

// Funkcja do formatowania daty
function formatDate(date, format = 'short') {
    const options = format === 'short' 
        ? { day: '2-digit', month: '2-digit', year: 'numeric' }
        : { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' };
    
    return new Date(date).toLocaleDateString('pl-PL', options);
}

// Funkcja do debouncing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
