<?php
/**
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */


class JApplication{
	public $input;
	public function __construct(){
		$this->input = new JInput();
	}
}
class JFactory{
	private static $application = null;
	static function getApplication(){
		if( !is_object( self::$application ) ){
			self::$application = new JApplication();
		}
		return self::$application;
	}
	
}
class JInput{
	public function get($name, $default = '', $from = 'request', $format = 'string'){
		return JRequest::getVar( $name, $default, $from, $format );
	}
	public function getArray( $data = array() ){
		if( is_array( $data ) ){
			$r = array();
			foreach( $data as $k => $v ){
				if( isset($_REQUEST[ $k ]) ){
					$tmp = $_REQUEST[ $k ];
					switch( $v ){
						case'int':
							$tmp = (int)$tmp;
						case'array':
							$tmp = (array)$tmp;
						case'string':
						default:
							$tmp = (string)$tmp;
					}
					$r[ $k ] = $tmp;
				}else{
					$r[ $k ] = '';
				}
			}
			return $r;
		}else{
			return array();
		}
	}
}
class JRequest{
	static function get( $from = null ){
		if($from == 'post') return $_POST;
		if($from == 'get') return $_GET;
	}
	static function getVar( $name, $default = '', $from = 'request', $format = 'string' ){
		switch( $from ){
			case'get': $from = $_GET;
				break;
			case'post': $from = $_POST;
				break;
			case'server': $from = $_SERVER;
				break;
			case'request':
			default:
				$from = $_REQUEST;
		}
		if( !empty( $from[$name] ) ){
			return $from[$name];
		}else{
			return $default;
		}
	}
	static function getInt( $name, $default = '', $from = 'request', $format = 'string' ){
		return (int) self::getVar( $name, $default, $from, $format );
	}
}
class JRoute{
	public static function _( $path ){
		return $path;
	}
}
class JError{
	public static function raiseError( $code = 500, $msg ){
		echo '<pre>'.print_r(array('raiseError',$code,$msg),true).'</pre>';die;
	}
}
abstract class JIObject{
	protected $_config;
	public function __construct( $config = array() ){
		$this->_config = $config;
	}
	/**
	*
	* @param $config array()
	*
	*/
	public static function getInstance( $className, $key = 'default', $config = array(), $instance = null ){
		static $_instance = array();
		if( is_object($instance) && $instance instanceof self ){
			$_instance[ $key ] = $instance;
			return $_instance[ $key ];
		}
		if( empty( $_instance[ $key ] ) ){
			$child_class_name = $className; // get_called_class(); - tylko w php 5.3+
			if( !is_array( $config ) ){
				$config = array();
			}
			$_instance[ $key ] = new $child_class_name( $config );
		}
		return $_instance[ $key ];
	}
}