# Copilot Instructions for comperia PHP Codebase

## Big Picture Architecture
- This is a modular PHP application, organized by feature and responsibility.
- Main entry points: `backend.php`, `comperia.php`, and `router.php` coordinate request handling and routing.
- Business logic is split into `models/` (data and domain logic), `controller.php` (request orchestration), and `view/` (templates for rendering output).
- Configuration is managed via `config.php`, `config.xml`, and `pl-PL.config.ini` (localization).
- Static assets (CSS, JS, images) are in `media_comperia/`.
- Plugins and update logic are in `plugin-updates/`.

## Developer Workflows
- No build system detected; code changes are reflected immediately.
- Debugging is typically done by editing PHP files and using browser-based inspection or logging.
- For plugin development, use files in `plugin-updates/` and reference `plugin-update-checker.php`.
- Caching is handled in `cache/` (clear this folder to reset cache).

## Project-Specific Conventions
- Views are organized by feature in `view/`, with subfolders for forms (`formularz`), lists (`lista`), and details (`szczegoly`).
- Each view type has a `default.php` and specialized templates (e.g., `default_kdf.php`).
- Models are named after their domain (e.g., `models/comperia.php`).
- CSS/JS for plugins are in `plugin-updates/css/` and `plugin-updates/js/`.
- Use `router.php` for adding new routes or endpoints.

## Integration Points
- External dependencies are minimal; most logic is custom PHP.
- For plugin updates, integrate with `plugin-update-checker.php`.
- Localization uses `pl-PL.config.ini`.
- Manifest files for media and plugins: `media_comperia/manifest.xml` and `plugin-updates/index.php`.

## Examples
- To add a new view template: create a new file in the appropriate `view/` subfolder and update routing in `router.php`.
- To add a new plugin: add files to `plugin-updates/` and register in `plugin-update-checker.php`.
- To change configuration: edit `config.php` or `config.xml`.

## Key Files & Directories
- `backend.php`, `comperia.php`, `router.php`: main entry points
- `models/`: business/domain logic
- `view/`: templates and rendering
- `plugin-updates/`: plugin system
- `media_comperia/`: static assets
- `config.php`, `config.xml`, `pl-PL.config.ini`: configuration

---
For unclear workflows or missing conventions, ask the user for clarification or examples from their daily development process.