<div class="text-center py-5 my-5">
    <h1 class="display-1 fw-bold text-primary">404</h1>
    <h2 class="mb-4">Strona nie została znaleziona</h2>
    <p class="lead mb-4">
        Przepraszamy, ale strona, której szukasz, nie istnieje lub została przeniesiona.
    </p>
    <a href="index.php" class="btn btn-primary btn-lg">
        <i class="bi bi-house-door"></i> Strona główna
    </a>
</div>
