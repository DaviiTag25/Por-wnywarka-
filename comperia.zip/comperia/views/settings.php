<?php
// Domyślne ustawienia (w rzeczywistej aplikacji byłyby pobierane z bazy danych)
$settings = [
    'site_title' => 'Comperia',
    'admin_email' => 'admin@example.com',
    'items_per_page' => 10,
    'timezone' => 'Europe/Warsaw',
    'date_format' => 'Y-m-d',
    'time_format' => 'H:i:s'
];

// Obsługa formularza ustawień
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobierz dane z formularza
    $settings['site_title'] = trim($_POST['site_title'] ?? '');
    $settings['admin_email'] = trim($_POST['admin_email'] ?? '');
    $settings['items_per_page'] = (int)($_POST['items_per_page'] ?? 10);
    $settings['timezone'] = $_POST['timezone'] ?? 'Europe/Warsaw';
    $settings['date_format'] = $_POST['date_format'] ?? 'Y-m-d';
    $settings['time_format'] = $_POST['time_format'] ?? 'H:i:s';
    
    // Tutaj w rzeczywistej aplikacji byłby kod zapisujący ustawienia do bazy danych
    // np. foreach ($settings as $key => $value) { save_setting($key, $value); }
    
    // Ustaw komunikat sukcesu
    $_SESSION['message'] = 'Ustawienia zostały zapisane.';
    
    // Przekieruj, aby uniknąć ponownego wysłania formularza
    header('Location: index.php?page=settings');
    exit();
}
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Ustawienia</h1>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <form method="post" action="">
                    <h5 class="mb-4">Ustawienia ogólne</h5>
                    
                    <div class="mb-3">
                        <label for="site_title" class="form-label">Nazwa strony</label>
                        <input type="text" class="form-control" id="site_title" name="site_title" 
                               value="<?php echo htmlspecialchars($settings['site_title']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="admin_email" class="form-label">E-mail administratora</label>
                        <input type="email" class="form-control" id="admin_email" name="admin_email" 
                               value="<?php echo htmlspecialchars($settings['admin_email']); ?>">
                        <div class="form-text">Na ten adres będą wysyłane powiadomienia systemowe.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="items_per_page" class="form-label">Liczba elementów na stronie</label>
                        <select class="form-select" id="items_per_page" name="items_per_page">
                            <?php for ($i = 5; $i <= 50; $i += 5): ?>
                                <option value="<?php echo $i; ?>" <?php echo $i == $settings['items_per_page'] ? 'selected' : ''; ?>>
                                    <?php echo $i; ?> elementów
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <hr class="my-4">
                    <h5 class="mb-4">Ustawienia daty i godziny</h5>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="timezone" class="form-label">Strefa czasowa</label>
                                <select class="form-select" id="timezone" name="timezone">
                                    <?php 
                                    $timezones = DateTimeZone::listIdentifiers(DateTimeZone::ALL);
                                    foreach ($timezones as $tz): 
                                        if (strpos($tz, '/') !== false): // Wyświetlaj tylko główne strefy czasowe
                                    ?>
                                        <option value="<?php echo $tz; ?>" <?php echo $tz === $settings['timezone'] ? 'selected' : ''; ?>>
                                            <?php echo str_replace('_', ' ', $tz); ?>
                                        </option>
                                    <?php 
                                        endif;
                                    endforeach; 
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="date_format" class="form-label">Format daty</label>
                                <select class="form-select" id="date_format" name="date_format">
                                    <option value="Y-m-d" <?php echo $settings['date_format'] === 'Y-m-d' ? 'selected' : ''; ?>>
                                        RRRR-MM-DD (<?php echo date('Y-m-d'); ?>)
                                    </option>
                                    <option value="d.m.Y" <?php echo $settings['date_format'] === 'd.m.Y' ? 'selected' : ''; ?>>
                                        DD.MM.RRRR (<?php echo date('d.m.Y'); ?>)
                                    </option>
                                    <option value="m/d/Y" <?php echo $settings['date_format'] === 'm/d/Y' ? 'selected' : ''; ?>>
                                        MM/DD/RRRR (<?php echo date('m/d/Y'); ?>)
                                    </option>
                                    <option value="d F Y" <?php echo $settings['date_format'] === 'd F Y' ? 'selected' : ''; ?>>
                                        DD Miesiąc RRRR (<?php echo date('d F Y'); ?>)
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="time_format" class="form-label">Format godziny</label>
                                <select class="form-select" id="time_format" name="time_format">
                                    <option value="H:i:s" <?php echo $settings['time_format'] === 'H:i:s' ? 'selected' : ''; ?>>
                                        24-godzinny (<?php echo date('H:i:s'); ?>)
                                    </option>
                                    <option value="h:i:s A" <?php echo $settings['time_format'] === 'h:i:s A' ? 'selected' : ''; ?>>
                                        12-godzinny (<?php echo date('h:i:s A'); ?>)
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="bi bi-save"></i> Zapisz zmiany
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Informacje o systemie</h5>
            </div>
            <div class="card-body">
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <strong>Wersja PHP:</strong> <?php echo phpversion(); ?>
                    </li>
                    <li class="mb-2">
                        <strong>Serwer WWW:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Nieznany'; ?>
                    </li>
                    <li class="mb-2">
                        <strong>Baza danych:</strong> MySQL
                    </li>
                    <li class="mb-2">
                        <strong>Limit pamięci:</strong> <?php echo ini_get('memory_limit'); ?>
                    </li>
                    <li class="mb-2">
                        <strong>Maksymalny rozmiar przesyłania:</strong> <?php echo ini_get('upload_max_filesize'); ?>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Pomoc i wsparcie</h5>
            </div>
            <div class="card-body">
                <p>Jeśli potrzebujesz pomocy, skontaktuj się z nami:</p>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <i class="bi bi-envelope me-2"></i> support@comperia.pl
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-telephone me-2"></i> +48 123 456 789
                    </li>
                    <li>
                        <i class="bi bi-clock me-2"></i> Pon-Pt: 9:00 - 17:00
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
// Podgląd formatu daty i godziny w czasie rzeczywistym
document.addEventListener('DOMContentLoaded', function() {
    const dateFormatSelect = document.getElementById('date_format');
    const timeFormatSelect = document.getElementById('time_format');
    const timezoneSelect = document.getElementById('timezone');
    
    // Funkcja aktualizująca podgląd
    function updatePreview() {
        // W rzeczywistości to powinno być wykonane po stronie serwera,
        // ale na potrzeby demonstracji używamy JavaScript
        const now = new Date();
        
        // Aktualizuj przykładowe daty w selectach
        const dateOptions = dateFormatSelect.querySelectorAll('option');
        dateOptions.forEach(option => {
            if (option.value) {
                const format = option.value;
                const formattedDate = formatDate(now, format);
                option.text = option.text.replace(/\(.+\)/, `(${formattedDate})`);
            }
        });
        
        const timeOptions = timeFormatSelect.querySelectorAll('option');
        timeOptions.forEach(option => {
            if (option.value) {
                const format = option.value;
                const formattedTime = formatTime(now, format);
                option.text = option.text.replace(/\(.+\)/, `(${formattedTime})`);
            }
        });
    }
    
    // Proste formatowanie daty (w rzeczywistości powinno być wykonane po stronie serwera)
    function formatDate(date, format) {
        const options = {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        };
        
        return date.toLocaleDateString('pl-PL', options);
    }
    
    // Proste formatowanie czasu (w rzeczywistości powinno być wykonane po stronie serwera)
    function formatTime(date, format) {
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: format.includes('A')
        };
        
        return date.toLocaleTimeString('pl-PL', options);
    }
    
    // Nasłuchuj zmian w formularzu
    dateFormatSelect.addEventListener('change', updatePreview);
    timeFormatSelect.addEventListener('change', updatePreview);
    
    // Inicjalizacja podglądu
    updatePreview();
});
</script>
