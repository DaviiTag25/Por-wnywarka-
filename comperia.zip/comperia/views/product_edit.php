<?php
// Sprawdź, czy przekazano ID produktu (edycja) czy nie (dodawanie nowego)
$is_edit = isset($_GET['id']);
$product_id = $is_edit ? (int)$_GET['id'] : 0;

// Pobierz instancję API Comperia
$comperiaAPI = getComperiaAPI();

// Domyślna struktura produktu (fallback, jeśli API nie zwróci części pól)
$product = [
    'id' => $product_id,
    'name' => '',
    'description' => '',
    'status' => 'draft',
    'date' => date('Y-m-d H:i:s'),
    'meta' => [
        'price' => '',
        'category' => '',
        'tags' => ''
    ]
];

// Jeśli to edycja, załaduj dane produktu z API
if ($is_edit) {
    try {
        $apiProduct = $comperiaAPI->getProductDetails($product_id);

        if (!is_array($apiProduct) || empty($apiProduct)) {
            $_SESSION['error'] = 'Nie znaleziono produktu o podanym ID w API.';
            header('Location: index.php?page=products');
            exit();
        }

        // Mapowanie pól z API na naszą strukturę formularza
        $product['id'] = $apiProduct['id'] ?? $product_id;
        $product['name'] = $apiProduct['name'] ?? '';
        $product['description'] = $apiProduct['description'] ?? '';
        $product['status'] = $apiProduct['status'] ?? 'draft';
        $product['date'] = $apiProduct['updated_at'] ?? ($apiProduct['created_at'] ?? $product['date']);

        // Jeśli API zwraca dodatkowe pola (cena, kategoria, tagi), spróbuj je zmapować
        if (isset($apiProduct['price'])) {
            $product['meta']['price'] = $apiProduct['price'];
        }
        if (isset($apiProduct['category'])) {
            // może być string lub tablica
            $product['meta']['category'] = is_array($apiProduct['category'])
                ? ($apiProduct['category']['name'] ?? '')
                : $apiProduct['category'];
        }
        if (isset($apiProduct['tags'])) {
            $product['meta']['tags'] = is_array($apiProduct['tags'])
                ? implode(', ', $apiProduct['tags'])
                : $apiProduct['tags'];
        }
    } catch (Exception $e) {
        $_SESSION['error'] = 'Nie udało się pobrać danych produktu z API: ' . $e->getMessage();
        header('Location: index.php?page=products');
        exit();
    }
}

// Obsługa formularza
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobierz i zweryfikuj dane z formularza
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'draft';
    // Formularz używa 'published', API/lista produktów używa 'publish'
    $status = $status === 'published' ? 'publish' : 'draft';

    // Pobierz metadane
    $meta_price = trim($_POST['meta_price'] ?? '');
    $meta_category = trim($_POST['meta_category'] ?? '');
    $meta_tags = trim($_POST['meta_tags'] ?? '');

    // Walidacja
    $errors = [];
    if (empty($name)) {
        $errors[] = 'Nazwa produktu jest wymagana.';
    }

    // Dane wysyłane do API – dopasuj do realnego kontraktu API, gdy go poznasz
    $payload = [
        'name' => $name,
        'description' => $description,
        'status' => $status,
    ];

    // Jeżeli API obsługuje dodatkowe pola, możemy je dodać do payloadu
    if ($meta_price !== '') {
        $payload['price'] = $meta_price;
    }
    if ($meta_category !== '') {
        $payload['category'] = $meta_category;
    }
    if ($meta_tags !== '') {
        // Jeśli API przyjmuje tablicę tagów, rozbij po przecinkach
        $payload['tags'] = array_map('trim', explode(',', $meta_tags));
    }

    // Jeśli nie ma błędów, zapisz produkt przez API
    if (empty($errors)) {
        try {
            if ($is_edit && $product_id > 0) {
                $comperiaAPI->updateProduct($product_id, $payload);
                $_SESSION['message'] = 'Produkt został zaktualizowany.';
            } else {
                $created = $comperiaAPI->createProduct($payload);
                // Jeśli API zwraca ID nowego produktu, możemy go wykorzystać
                if (isset($created['id'])) {
                    $product_id = (int)$created['id'];
                }
                $_SESSION['message'] = 'Produkt został dodany.';
            }

            // Przekieruj na listę produktów
            header('Location: index.php?page=products');
            exit();
        } catch (Exception $e) {
            $errors[] = 'Błąd podczas zapisu do API: ' . $e->getMessage();
            $_SESSION['error'] = implode('<br>', $errors);
        }
    } else {
        // Przy błędach walidacji odtwórz wartości w $product, żeby formularz je pokazał
        $product['name'] = $name;
        $product['description'] = $description;
        $product['status'] = $status;
        $product['meta']['price'] = $meta_price;
        $product['meta']['category'] = $meta_category;
        $product['meta']['tags'] = $meta_tags;
        $_SESSION['error'] = implode('<br>', $errors);
    }
}
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo $is_edit ? 'Edytuj produkt' : 'Dodaj nowy produkt'; ?></h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="index.php?page=products" class="btn btn-sm btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Wróć do listy produktów
        </a>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
        <h5>Wystąpiły błędy:</h5>
        <ul class="mb-0">
            <?php foreach ($errors as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" action="" class="needs-validation" novalidate>
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nazwa produktu <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-lg" id="name" name="name" 
                               value="<?php echo htmlspecialchars($product['name']); ?>" required>
                        <div class="invalid-feedback">
                            Proszę podać nazwę produktu.
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Opis produktu</label>
                        <textarea class="form-control" id="description" name="description" rows="8"><?php 
                            echo htmlspecialchars($product['description']); 
                        ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="status_published" 
                                   value="published" <?php echo $product['status'] === 'published' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="status_published">
                                Opublikowany
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="status" id="status_draft" 
                                   value="draft" <?php echo $product['status'] !== 'published' ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="status_draft">
                                Szkic
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Metadane</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="meta_price" class="form-label">Cena / Zakres cen</label>
                        <input type="text" class="form-control" id="meta_price" name="meta_price" 
                               value="<?php echo htmlspecialchars($product['meta']['price']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="meta_category" class="form-label">Kategoria</label>
                        <select class="form-select" id="meta_category" name="meta_category">
                            <option value="">Wybierz kategorię</option>
                            <option value="Kredyty gotówkowe" <?php echo $product['meta']['category'] === 'Kredyty gotówkowe' ? 'selected' : ''; ?>>Kredyty gotówkowe</option>
                            <option value="Karty kredytowe" <?php echo $product['meta']['category'] === 'Karty kredytowe' ? 'selected' : ''; ?>>Karty kredytowe</option>
                            <option value="Konta osobiste" <?php echo $product['meta']['category'] === 'Konta osobiste' ? 'selected' : ''; ?>>Konta osobiste</option>
                            <option value="Pożyczki" <?php echo $product['meta']['category'] === 'Pożyczki' ? 'selected' : ''; ?>>Pożyczki</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="meta_tags" class="form-label">Tagi</label>
                        <input type="text" class="form-control" id="meta_tags" name="meta_tags" 
                               value="<?php echo htmlspecialchars($product['meta']['tags']); ?>" 
                               placeholder="oddziel tagi przecinkami">
                        <div class="form-text">Słowa kluczowe oddzielone przecinkami</div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Akcje</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button type="submit" name="save" class="btn btn-primary">
                            <i class="bi bi-save"></i> Zapisz zmiany
                        </button>
                        
                        <?php if ($is_edit): ?>
                            <a href="index.php?page=products&action=delete&id=<?php echo $product_id; ?>" 
                               class="btn btn-outline-danger delete-btn"
                               onclick="return confirm('Czy na pewno chcesz usunąć ten produkt? Tej operacji nie można cofnąć.')">
                                <i class="bi bi-trash"></i> Usuń produkt
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
// Włącz walidację formularza po stronie klienta
(function () {
    'use strict'
    
    // Pobierz wszystkie formularze, do których chcemy dodać walidację
    var forms = document.querySelectorAll('.needs-validation')
    
    // Pętla po nich i zapobiegaj wysłaniu
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                
                form.classList.add('was-validated')
            }, false)
        })
})()

// Inicjalizacja edytora tekstu (w pełnej wersji można dodać np. TinyMCE)
document.addEventListener('DOMContentLoaded', function() {
    // Tutaj można dodać inicjalizację edytora WYSIWYG
    // np. tinymce.init({ selector: '#description' });
});
</script>
