<?php
// Pobranie instancji API Comperia
$comperiaAPI = getComperiaAPI();
$message = '';
$products = [];
$error = '';

// Obsługa akcji na produktach
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $product_id = (int)$_GET['id'];
    
    try {
        switch ($action) {
            case 'publish':
                $result = $comperiaAPI->updateProductStatus($product_id, 'publish');
                $message = 'Produkt został opublikowany.';
                break;
                
            case 'trash':
                $result = $comperiaAPI->updateProductStatus($product_id, 'trash');
                $message = 'Produkt został przeniesiony do kosza.';
                break;
                
            case 'delete':
                // Uwaga: W zależności od API może być wymagane inne wywołanie do usunięcia produktu
                // W tym przykładzie zakładamy, że update statusu na 'delete' usunie produkt
                $result = $comperiaAPI->updateProductStatus($product_id, 'delete');
                $message = 'Produkt został usunięty.';
                break;
                
            case 'restore':
                $result = $comperiaAPI->updateProductStatus($product_id, 'draft');
                $message = 'Produkt został przywrócony ze statusem szkicu.';
                break;
        }
        
        $_SESSION['message'] = $message;
    } catch (Exception $e) {
        $error = 'Wystąpił błąd podczas wykonywania operacji: ' . $e->getMessage();
        $_SESSION['error'] = $error;
    }
    
    // Przekierowanie, aby uniknąć ponownego wysłania formularza przy odświeżeniu
    header('Location: index.php?page=products');
    exit();
}

// Pobranie listy produktów z API
$status = isset($_GET['status']) ? $_GET['status'] : 'publish';
$page = isset($_GET['paged']) ? (int)$_GET['paged'] : 1;
$per_page = 10; // Liczba produktów na stronę

try {
    // Pobranie produktów z API z uwzględnieniem paginacji i statusu
    $params = [
        'status' => $status,
        'per_page' => $per_page,
        'page' => $page
    ];
    
    $response = $comperiaAPI->getProducts($params);
    
    // Przetworzenie odpowiedzi z API
    if (isset($response['data']) && is_array($response['data'])) {
        $products = $response['data'];
        $total_items = $response['total'] ?? count($products);
        $total_pages = $response['last_page'] ?? 1;
    } else {
        // Jeśli odpowiedź nie zawiera spodziewanej struktury, traktuj całą odpowiedź jako listę produktów
        $products = is_array($response) ? $response : [];
        $total_items = count($products);
        $total_pages = 1;
    }
} catch (Exception $e) {
    $error = 'Nie udało się pobrać listy produktów: ' . $e->getMessage();
    $_SESSION['error'] = $error;
    $products = [];
    $total_items = 0;
    $total_pages = 1;
}
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Produkty</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="index.php?page=product_edit" class="btn btn-sm btn-outline-primary">
            <i class="bi bi-plus-circle"></i> Dodaj nowy produkt
        </a>
    </div>
</div>

<?php if (!empty($error)): ?>
<div class="alert alert-danger">
    <?php echo $error; ?>
</div>
<?php endif; ?>

<!-- Filtry i wyszukiwanie -->
<div class="row mb-3">
    <div class="col-md-8">
        <div class="btn-group" role="group">
            <a href="?page=products&status=publish" class="btn btn-outline-primary <?php echo ($status === 'publish') ? 'active' : ''; ?>">
                Wszystkie (<?php echo $total_items; ?>)
            </a>
            <a href="?page=products&status=draft" class="btn btn-outline-secondary <?php echo ($status === 'draft') ? 'active' : ''; ?>">
                Szkice
            </a>
            <a href="?page=products&status=trash" class="btn btn-outline-danger <?php echo ($status === 'trash') ? 'active' : ''; ?>">
                Kosz
            </a>
        </div>
    </div>
    <div class="col-md-4">
        <form method="get" action="" class="d-flex">
            <input type="hidden" name="page" value="products">
            <input type="hidden" name="status" value="<?php echo $status; ?>">
            <input type="text" name="s" class="form-control me-2" placeholder="Szukaj produktów..." value="<?php echo isset($_GET['s']) ? htmlspecialchars($_GET['s']) : ''; ?>">
            <button type="submit" class="btn btn-outline-secondary">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>Nazwa produktu</th>
                <th>ID</th>
                <th>Status</th>
                <th>Data aktualizacji</th>
                <th class="text-end">Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): 
                    $product_id = $product['id'] ?? 0;
                    $product_name = $product['name'] ?? 'Brak nazwy';
                    $product_status = $product['status'] ?? 'draft';
                    $updated_at = !empty($product['updated_at']) ? date('Y-m-d H:i', strtotime($product['updated_at'])) : 'Nieznana';
                    $edit_link = 'index.php?page=product_edit&id=' . $product_id;
                ?>
                <tr>
                    <td>
                        <strong>
                            <a href="<?php echo $edit_link; ?>">
                                <?php echo htmlspecialchars($product_name); ?>
                            </a>
                        </strong>
                    </td>
                    <td>#<?php echo $product_id; ?></td>
                    <td>
                        <span class="badge bg-<?php 
                            echo $product_status === 'publish' ? 'success' : 
                                ($product_status === 'draft' ? 'warning' : 'secondary'); 
                        ?>">
                            <?php 
                            $statuses = [
                                'publish' => 'Opublikowany',
                                'draft' => 'Szkic',
                                'trash' => 'Kosz',
                                'pending' => 'Oczekujący',
                                'private' => 'Prywatny'
                            ];
                            echo $statuses[$product_status] ?? $product_status;
                            ?>
                        </span>
                    </td>
                    <td><?php echo $updated_at; ?></td>
                    <td class="text-end">
                        <div class="btn-group btn-group-sm" role="group">
                            <a href="<?php echo $edit_link; ?>" class="btn btn-outline-primary" title="Edytuj">
                                <i class="bi bi-pencil"></i>
                            </a>
                            
                            <?php if ($product_status !== 'publish' && $product_status !== 'trash'): ?>
                                <a href="?page=products&action=publish&id=<?php echo $product_id; ?>" class="btn btn-outline-success" title="Opublikuj">
                                    <i class="bi bi-check-lg"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php if ($product_status === 'trash'): ?>
                                <a href="?page=products&action=restore&id=<?php echo $product_id; ?>" class="btn btn-outline-info" title="Przywróć">
                                    <i class="bi bi-arrow-counterclockwise"></i>
                                </a>
                                <a href="?page=products&action=delete&id=<?php echo $product_id; ?>" class="btn btn-outline-danger" title="Usuń na stałe" onclick="return confirm('Czy na pewno chcesz trwale usunąć ten produkt? Tej operacji nie można cofnąć.');">
                                    <i class="bi bi-trash-fill"></i>
                                </a>
                            <?php else: ?>
                                <a href="?page=products&action=trash&id=<?php echo $product_id; ?>" class="btn btn-outline-warning" title="Przenieś do kosza">
                                    <i class="bi bi-trash"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center py-4">
                        <div class="text-muted">
                            <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                            <p class="mt-2 mb-0">
                                <?php 
                                if ($status === 'trash') {
                                    echo 'Kosz jest pusty. Usunięte produkty będą tutaj widoczne przez 30 dni.';
                                } else {
                                    echo 'Brak produktów do wyświetlenia.';
                                    if ($status === 'publish') {
                                        echo ' <a href="index.php?page=product_edit">Dodaj nowy produkt</a>';
                                    }
                                }
                                ?>
                            </p>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if ($total_pages > 1): ?>
<nav aria-label="Nawigacja po stronach" class="mt-4">
    <ul class="pagination justify-content-center">
        <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
            <a class="page-link" href="?page=products&status=<?php echo $status; ?>&paged=<?php echo max(1, $page - 1); ?>" tabindex="-1" aria-disabled="<?php echo ($page <= 1) ? 'true' : 'false'; ?>">
                Poprzednia
            </a>
        </li>
        
        <?php for ($i = 1; $i <= min(5, $total_pages); $i++): ?>
            <?php if ($i === $page): ?>
                <li class="page-item active" aria-current="page">
                    <span class="page-link"><?php echo $i; ?></span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link" href="?page=products&status=<?php echo $status; ?>&paged=<?php echo $i; ?>">
                        <?php echo $i; ?>
                    </a>
                </li>
            <?php endif; ?>
        <?php endfor; ?>
        
        <?php if ($total_pages > 5): ?>
            <li class="page-item disabled">
                <span class="page-link">...</span>
            </li>
            <li class="page-item">
                <a class="page-link" href="?page=products&status=<?php echo $status; ?>&paged=<?php echo $total_pages; ?>">
                    <?php echo $total_pages; ?>
                </a>
            </li>
        <?php endif; ?>
        
        <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
            <a class="page-link" href="?page=products&status=<?php echo $status; ?>&paged=<?php echo min($total_pages, $page + 1); ?>" aria-disabled="<?php echo ($page >= $total_pages) ? 'true' : 'false'; ?>">
                Następna
            </a>
        </li>
    </ul>
</nav>
<?php endif; ?>

<script>
// Obsługa zaznaczania wszystkich checkboxów
document.addEventListener('DOMContentLoaded', function() {
    const selectAllCheckbox = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name="product_ids[]"]');
    
    if (selectAllCheckbox && checkboxes.length > 0) {
        selectAllCheckbox.addEventListener('change', function() {
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });
        
        // Sprawdzanie, czy wszystkie checkboxy są zaznaczone
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const allChecked = Array.from(checkboxes).every(cb => cb.checked);
                selectAllCheckbox.checked = allChecked;
            });
        });
    }
    
    // Wyświetlanie komunikatów
    <?php if (isset($_SESSION['message'])): ?>
        alert('<?php echo addslashes($_SESSION['message']); ?>');
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        alert('Błąd: <?php echo addslashes($_SESSION['error']); ?>');
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
});
</script>
