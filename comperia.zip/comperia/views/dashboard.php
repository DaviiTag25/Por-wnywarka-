<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Panel główny</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary">Eksportuj</button>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h5 class="card-title">Liczba produktów</h5>
                <p class="card-text display-4">0</p>
                <a href="index.php?page=products" class="text-white">Zobacz produkty <i class="bi bi-arrow-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h5 class="card-title">Aktywne oferty</h5>
                <p class="card-text display-4">0</p>
                <a href="#" class="text-white">Zobacz oferty <i class="bi bi-arrow-right"></i></a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title">Użytkownicy</h5>
                <p class="card-text display-4">1</p>
                <a href="#" class="text-white">Zarządzaj użytkownikami <i class="bi bi-arrow-right"></i></a>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">Ostatnia aktywność</h5>
    </div>
    <div class="card-body">
        <p>Brak ostatniej aktywności do wyświetlenia.</p>
    </div>
</div>
