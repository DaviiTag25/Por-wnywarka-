<?php
/**
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

class Comperia_Widget extends WP_Widget {

	public $produkt;
	public $item = null; // for view
	
	public function __construct( $produkt = null ) {
		
		parent::__construct(
	 		'Comperia_Widget', // Base ID
			'Comperia Widget', // Name
			array( 'description' => __( 'Widget wyświetlający formularz wyszukiwania ofert finansowych', 'text_domain' ) ) // Args
		);

	}

	public function widget( $args, $instance ) {
		$this->model		= ComperiaModel::getInstance('ComperiaModel');
		$this->title		= $instance['title'];
		$this->produkt 	= $instance['produkt'];
		$this->response	= $this->model->getForm($instance['produkt'] , array(), false );
		$layoutFile = COMPERIA_PATH_PLUGIN . '/view/formularz/' . $instance['layout'];
		
		if( file_exists( $layoutFile ) ){
			require $layoutFile;
		}else{
			echo 'Nie znaleziono pliku szablonu';
		}
	}

 	public function form( $instance ) {
			$pageOptions = pageOptions::getInstance('pageOptions');
			$existing = $pageOptions->get_existing_comperia_pages();
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'produkt' ); ?>"><?php _e( 'Produkt:' ); ?></label>
			<select id="<?php echo $this->get_field_id( 'produkt' ); ?>" name="<?php echo $this->get_field_name( 'produkt' ); ?>"
				onchange="setTitleIfNotSet()" title="Jeśli istnieją nieaktywne pozycje, to należy stworzyć stronę i przypisać do niej produkt"
			>
				<option value=""><?php echo _e( 'Wybierz &hellip;' ); ?></option>
				<?php foreach( ComperiaHelper::$produkty as $k => $p ): 
					$selected = $instance['produkt'] == $k ? 'selected="selected" ' : '' ;
					$disabled = 'disabled="disabled" ';
					if( $k <> 'pzb' ){ //pzb nie posiada formularza, więc wyłączamy
						foreach( $existing as $kEx => $vEx ){
							if( $k == $kEx ){
								$disabled = '';
								break;
							}
						}
					}
				?>
					<option <?php echo $selected.$disabled; ?>value="<?php echo $k; ?>"><?php echo $p['pl']; ?></option>
				<?php endforeach; ?>
			</select>
		</p>		
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" 
					class="widefat" type="text" value="<?php echo empty($instance['title']) ? '' : esc_attr( $instance['title'] ); ?>" 
			/>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'layout' ); ?>"><?php _e( 'Layout:' ); ?></label> 
			<select id="<?php echo $this->get_field_id( 'layout' ); ?>" name="<?php echo $this->get_field_name( 'layout' ); ?>">
				<?php foreach( glob( COMPERIA_PATH_PLUGIN . "/view/formularz/[!_]*.php") as $f ): // "_.*" to podszablon;patrz:joomla
					$f = basename( $f );
					$selected = $instance['layout'] == $f ? 'selected="selected" ' : ' ' ;
				?>
					<option <?php echo $selected; ?> value="<?php echo $f ; ?>"><?php echo $f ; ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<script>
			function setTitleIfNotSet(){
				var produkt	= document.getElementById("<?php echo $this->get_field_id( 'produkt' ); ?>");
				var title	= document.getElementById("<?php echo $this->get_field_id( 'title' );   ?>");
				if( title.defaultValue == '' ){
					title.value = produkt.options[ produkt.selectedIndex ].text;
				}
			}
		</script>
		<?php 
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		
		$configFields = array('title','produkt','layout');
		foreach( $configFields as $v ){
			$instance[ $v ] = ( !empty( $new_instance[ $v ] ) ) ? strip_tags( $new_instance[ $v ] ) : '';
		}
		
		return $instance;

	}

}

