
// Niezależna witryna Comperia Plugin
// index.php - punkt wejścia

// Prosty routing na podstawie parametru 'page'
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

function comperia_render_header($title = 'Comperia - Strona testowa') {
    echo '<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . htmlspecialchars($title) . '</title>
    <link rel="stylesheet" href="css/comperia-plugin.css" type="text/css" media="all" />
</head>
<body>';
}

function comperia_render_footer() {
    echo '</body></html>';
}

function comperia_render_home() {
    echo '<div class="comperia-admin-wrap">
        <h1>Witamy na stronie Comperia!</h1>
        <p>To jest przykładowa strona główna projektu Comperia.</p>
        <div>
            <strong>Instrukcja obsługi:</strong>
            <ul>
                <li>Dodaj swoją funkcjonalność do pliku index.php</li>
                <li>Edytuj style w pliku CSS, aby dostosować wygląd</li>
            </ul>
        </div>
    </div>';
}

function comperia_render_about() {
    echo '<div class="comperia-admin-wrap">
        <h2>O wtyczce</h2>
        <p>Ta witryna działa jako niezależna instancja wtyczki Comperia.</p>
    </div>';
}

// Routing
comperia_render_header();
switch ($page) {
    case 'about':
        comperia_render_about();
        break;
    case 'home':
    default:
        comperia_render_home();
        break;
}
comperia_render_footer();
