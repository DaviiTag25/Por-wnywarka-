<?php
/**
 * Lista lokaty bankowe
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?> / <?php echo $this->descriptions['oferta']; ?></th>
		<th><?php echo $this->descriptions['oprocentowanie']; ?></th>
		<th><?php echo $this->descriptions['odsetki_przed_opodatkowaniem']; ?></th>
		<th><?php echo $this->descriptions['odsetki_po_podatku']; ?></th>
		<?php if(0): ?><th><?php echo $this->descriptions['wymagania']; ?></th><?php endif; ?>
		<?php if(0): ?><th><?php echo $this->descriptions['zerwanie_lokaty']; ?></th><?php endif; ?>
		<th><?php echo $this->descriptions['sposob_zalozenia']; ?></th>
		<th><?php echo $this->descriptions['dostepna_u_doradcy']; ?></th>
		<th>Wniosek/&shy;Szczegóły</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="firstTr basics">
		<td rowspan="2">
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['oprocentowanie']; ?></span>
			<span class="unit" ><?php echo $this->units['oprocentowanie']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['odsetki_przed_opodatkowaniem']; ?></span>
			<span class="unit" ><?php echo $this->units['odsetki_przed_opodatkowaniem']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['odsetki_po_podatku']; ?></span>
			<span class="unit" ><?php echo $this->units['odsetki_po_podatku']; ?></span>
		</td>
		<?php if(0): ?><td><?php echo $this->offer['wymagania']; ?></td><?php endif; ?>
		<?php if(0): ?><td><?php echo $this->offer['zerwanie_lokaty']; ?></td><?php endif; ?>
		<td><?php echo $this->offer['sposob_zalozenia']; ?></td>
		<td><?php echo $this->offer['dostepna_u_doradcy']; ?></td>
		<td>
			<?php echo $this->a_wniosek($this->offer['link']); ?><br>
			<?php echo $this->a_szczegoly($this->offer['szczegoly']); ?>
		</td>
	</tr>
	<tr class="secoundTr pm">
		<td colspan="7">
			<?php echo $this->getPM($this->descriptions,$this->offer); ?>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>