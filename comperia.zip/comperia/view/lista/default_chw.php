<?php
/**
 * Lista szybkie gotówki
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?></th>
		<th>Kwota pożyczki</th>
		<th>Okres spłaty</th>
		<th><?php echo $this->descriptions['zaswiadczenie_o_zarobkach']; ?></th>
		<th><?php echo $this->descriptions['bik']; ?></th>
		<th><?php echo $this->descriptions['kanal_sprzedazy']; ?></th>
		<th>Wniosek</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="firstTr basics">
		<td rowspan="2">
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="trait"><?php echo $this->descriptions['kwota_min']; ?>: </span>
			<span class="value"><?php echo $this->offer['kwota_min']; ?></span>
			<span class="unit" ><?php echo $this->units['kwota_min']; ?></span>
			<span class="trait"><?php echo $this->descriptions['kwota_max']; ?>: </span>
			<span class="value"><?php echo $this->offer['kwota_max']; ?></span>
			<span class="unit" ><?php echo $this->units['kwota_max']; ?></span>
		</td>
		<td>
			<span class="trait"><?php echo $this->descriptions['okres_min']; ?>: </span>
				<?php if(isset($this->offer['okres_min']) && $this->offer['okres_min'] !== ''): ?>
					<span class="value"><?php echo $this->offer['okres_min']; ?></span>
					<span class="unit" ><?php echo $this->units['okres_min']; ?></span>
				<?php else: ?>
					<span class="value">-</span>
				<?php endif; ?>
			<span class="trait"><?php echo $this->descriptions['okres_max']; ?>: </span>
				<?php if(isset($this->offer['okres_max']) && $this->offer['okres_max'] !== ''): ?>
					<span class="value"><?php echo $this->offer['okres_max']; ?></span>
					<span class="unit" ><?php echo $this->units['okres_max']; ?></span>
				<?php else: ?>
					<span class="value">-</span>
				<?php endif; ?>
		</td>
		<td>
			<span class="<?php echo htmlentities($this->offer['zaswiadczenie_o_zarobkach']); ?>"><?php echo $this->offer['zaswiadczenie_o_zarobkach']; ?></span>
		</td>
		<td>
			<span class="<?php echo htmlentities($this->offer['bik']); ?>"><?php echo $this->offer['bik']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['kanal_sprzedazy']; ?></span>
		</td>
		<td><?php echo $this->a_wniosek($this->offer['link']); ?></td>
	</tr>
	<tr class="secoundTr">
		<td colspan="6" class="moreContent">
			<p>
				<span class="trait"><?php echo $this->descriptions['dodatkowe_informacje']; ?>: </span>
				<span class="value"><?php echo $this->offer['dodatkowe_informacje']; ?></span>
				<span class="unit" ><?php echo $this->units['dodatkowe_informacje']; ?></span>
			</p>
			<p>
				<span class="trait"><?php echo $this->descriptions['czestotliwosc_splaty']; ?>: </span>
				<span class="value"><?php echo $this->offer['czestotliwosc_splaty']; ?></span>
				<span class="unit" ><?php echo $this->units['czestotliwosc_splaty']; ?></span>
			</p>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>