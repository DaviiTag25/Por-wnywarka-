<?php
/**
 * Lista konta osobiste
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?> / <?php echo $this->descriptions['oferta']; ?></th>
		<th><?php echo $this->descriptions['odsetki_po_podatku']; ?></th>
		<th><?php echo $this->descriptions['koszt_uzytkowania']; ?></th>
		<th><?php echo $this->descriptions['oplata_za_prowadzenie']; ?></th>
		<th><?php echo $this->descriptions['darmowe_bankomaty']; ?></th>
		<th><?php echo $this->descriptions['oplata_za_karte']; ?></th>
		<th><?php echo $this->descriptions['dostep_do_konta']; ?></th>
		<?php if(0): ?><th><?php echo $this->descriptions['karty_do_konta']; ?></th><?php endif; ?>
		<th>Wniosek/&shy;Szczegóły</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="firstTr basics">
		<td rowspan="2">
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['odsetki_po_podatku']; ?></span>
			<span class="unit" ><?php echo $this->units['odsetki_po_podatku']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['koszt_uzytkowania']; ?></span>
			<span class="unit" ><?php echo $this->units['koszt_uzytkowania']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['oplata_za_prowadzenie']; ?></span>
			<span class="unit" ><?php echo $this->units['oplata_za_prowadzenie']; ?></span>
		</td>
		<td>
			<span class="<?php echo htmlentities($this->offer['darmowe_bankomaty']); ?>"><?php echo $this->offer['darmowe_bankomaty']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['oplata_za_karte']; ?></span>
			<span class="unit" ><?php echo $this->units['oplata_za_karte']; ?></span>
		</td>
		<td class="moreContent">
			<span><?php echo $this->offer['dostep_do_konta']; ?></span>
		</td>
		<?php if(0): ?>
		<td class="moreContent">
			<span><?php echo $this->offer['karty_do_konta']; ?></span>
		</td>
		<?php endif; ?>
		<td>
			<?php echo $this->a_wniosek($this->offer['link']); ?><br>
			<?php echo $this->a_szczegoly($this->offer['szczegoly']); ?>
		</td>
	</tr>
	<tr class="secoundTr pm">
		<td colspan="8" class="moreContent">
			<?php if(0): ?>
			<div><b><?php echo $this->descriptions['dodatkowe_korzysci']; ?></b>:
				<?php echo $this->offer['dodatkowe_korzysci'] . $this->units['dodatkowe_korzysci']; ?></div>
			<?php endif; ?>
			<?php echo $this->getPM($this->descriptions,$this->offer); ?>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>
