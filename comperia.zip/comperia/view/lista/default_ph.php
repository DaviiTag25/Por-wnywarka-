<?php
/**
 * Lista kredyty gotówkowe
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?> / <?php echo $this->descriptions['oferta']; ?></th>
		<th><?php echo $this->descriptions['rata']; ?></th>
		<th><?php echo $this->descriptions['prowizja']; ?></th>
		<th><?php echo $this->descriptions['oprocentowanie']; ?></th>
		<th><?php echo $this->descriptions['min_wklad_wlasny']; ?></th>
		<th>Wniosek/&shy;Szczegóły</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="firstTr basics">
		<td rowspan="2">
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['rata']; ?></span>
			<span class="unit" ><?php echo $this->units['rata']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['prowizja']; ?></span>
			<span class="unit" ><?php echo $this->units['prowizja']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['oprocentowanie']; ?></span>
			<span class="unit" ><?php echo $this->units['oprocentowanie']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['min_wklad_wlasny']; ?></span>
			<span class="unit" ><?php echo $this->units['min_wklad_wlasny']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->a_wniosek($this->offer['link']); ?><br>
			<span class="unit" ><?php echo $this->a_szczegoly($this->offer['szczegoly']); ?>
		</td>
	</tr>
	<tr class="secoundTr pm">
		<td colspan="5" class="moreContent">
			<?php echo $this->getPM($this->descriptions,$this->offer); ?>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>