<?php
/**
 * Lista leasing
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?></th>
		<th><?php echo $this->descriptions['rata_miesieczna']; ?></th>
		<th><?php echo $this->descriptions['czynsz']; ?></th>
		<th><?php echo $this->descriptions['suma_oplat']; ?></th>
		<th>Wniosek/&shy;Szczegóły</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="firstTr basics">
		<td rowspan="2">
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['rata_miesieczna']; ?></span>
			<span class="unit" ><?php echo $this->units['rata_miesieczna']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['czynsz']; ?></span>
			<span class="unit" ><?php echo $this->units['czynsz']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['suma_oplat']; ?></span>
			<span class="unit" ><?php echo $this->units['suma_oplat']; ?></span>
		</td>
		<td>
			<?php echo $this->a_wniosek($this->offer['link']); ?><br>
			<?php echo $this->a_szczegoly($this->offer['szczegoly']); ?>
		</td>
	</tr>
	<tr class="secoundTr pm">
		<td colspan="4" class="moreContent">
			<?php echo $this->getPM($this->descriptions,$this->offer); ?>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>