<?php
/**
 * Lista produkty pozabankowe
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
//show form?
if( JRequest::get('post') === array() ){ // wyszukiwanie nie odbyło się
	switch( $this->active->params->get('showFormOnListDef',0) ){
		case 0:$showForm = 1;$showResults = 1;
			break;
		case 1:$showForm = 0;$showResults = 1;
			break;
		case 2:$showForm = 1;$showResults = 0;
			break;
	}
}else{
	switch( $this->active->params->get('showFormOnListSearch',0) ){
		case 0:$showForm = 1;$showResults = 1;
			break;
		case 1:$showForm = 0;$showResults = 1;
			break;
	}
}
?>
<div id="com_comperia">
	<h2><?php echo $this->params->get('page_title'); ?></h2>
	<?php if($this->active->params->get('tekst_list_top','')) echo '<p>' . $this->active->params->get('tekst_list_top') . '</p>'; ?>
	<?php if($showForm) echo $this->getForm(); ?>
	<?php if ( $this->responseExist() && $showResults ):
		$this->units = $this->results['odpowiedz']['jednostki'];
		$this->descriptions = $this->results['odpowiedz']['opisy'];
	?>
		<?php if( isset($this->results['odpowiedz']['wybor']) && !empty($this->results['odpowiedz']['wybor']) ): ?>
			<div class="wybor">
				<strong>Twoje kryteria wyboru: </strong>
				<p><?php echo $this->results['odpowiedz']['wybor']; ?></p>
			</div>
		<?php endif; ?>
		<table id="lista_<?php echo $this->produkt; ?>" class="wyniki" border="1" cellpadding="0" cellspacing="0">
			<?php if($this->active->params->get('tableCaption','')): ?>
				<caption><h2><?php echo ComperiaHelper::$productsPol[$this->produkt]; ?></h2></caption>
			<?php endif; ?>
			<?php echo $this->loadTemplate( $this->produkt ); ?>
		</table>
		<div class="comperia-stopka">
		<?php echo ComperiaHelper::stopka( $this->results ); ?>
		</div>
	<?php else: ?>
		<?php if( !$this->responseExist() ): ?>
			<?php echo '<p>'.( $this->model->error ? $this->model->error : 'Brak wyników' ).'</p>'; ?>
		<?php endif; ?>
	<?php endif; ?>
	<?php if($this->active->params->get('tekst_list_bottom','')) echo '<p>' . $this->active->params->get('tekst_list_bottom') . '</p>'; ?>
</div>