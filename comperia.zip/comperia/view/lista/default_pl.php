<?php
/**
 * Lista polisolokaty
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?> / <?php echo $this->descriptions['oferta']; ?></th>
		<th><?php echo $this->descriptions['oprocentowanie']; ?></th>
		<th><?php echo $this->descriptions['odsetki_przed_opodatkowaniem']; ?></th>
		<th><?php echo $this->descriptions['odsetki_po_podatku']; ?></th>
		<th>Wniosek/&shy;Szczegóły</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="singleTr">
		<td>
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['oprocentowanie']; ?></span>
			<span class="unit" ><?php echo $this->units['oprocentowanie']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['odsetki_przed_opodatkowaniem']; ?></span>
			<span class="unit" ><?php echo $this->units['odsetki_przed_opodatkowaniem']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['odsetki_po_podatku']; ?></span>
			<span class="unit" ><?php echo $this->units['odsetki_po_podatku']; ?></span>
		</td>
		<td>
			<?php echo $this->a_wniosek($this->offer['link']); ?><br>
			<?php echo $this->a_szczegoly($this->offer['szczegoly']); ?>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>