<?php
/**
 * Lista lokaty strukturyzowane
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?> / <?php echo $this->descriptions['oferta']; ?></th>
		<th><?php echo $this->descriptions['poziom_ochrony_kapitalu']; ?></th>
		<th><?php echo $this->descriptions['koniec_subskrypcji']; ?></th>
		<th><?php echo $this->descriptions['oplata_wstepna']; ?></th>
		<th><?php echo $this->descriptions['forma_prawna']; ?></th>
		<th><?php echo $this->descriptions['sposob_zalozenia']; ?></th>
		<th><?php echo $this->descriptions['maksymalny_zysk']; ?></th>
		<th>Wniosek/&shy;Szczegóły</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="firstTr basics">
		<td rowspan="2">
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['poziom_ochrony_kapitalu'];?></span>
			<span class="unit" ><?php echo $this->units['poziom_ochrony_kapitalu']; ?></span>
		</td>
		<td><?php echo $this->offer['koniec_subskrypcji']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['oplata_wstepna']; ?></span>
			<span class="unit" ><?php echo $this->units['oplata_wstepna']; ?></span>
		</td>
		<td><?php echo $this->offer['forma_prawna']; ?></td>
		<td><?php echo $this->offer['sposob_zalozenia']; ?></td>
		<td><?php echo $this->offer['maksymalny_zysk']; ?></td>
		<td>
			<?php echo $this->a_wniosek($this->offer['link']); ?><br>
			<?php echo $this->a_szczegoly($this->offer['szczegoly']); ?>
		</td>
	</tr>
	<tr class="secoundTr pm">
		<td colspan="7" class="moreContent">
			<p><b><?php echo $this->descriptions['oplata_za_zerwanie']; ?></b>: <?php echo$this->offer['oplata_za_zerwanie']; ?></p>
			<?php echo $this->getPM($this->descriptions,$this->offer); ?>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>