<?php
/**
 * Lista produkty pozabankowe
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<thead>
	<tr>
		<th><?php echo $this->descriptions['bank']; ?></th>
		<th><?php echo $this->descriptions['opis']; ?></th>
		<th>Wniosek</th>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="singleTr">
		<td>
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td class=""><?php echo ((isset($this->offer['opis']) && !empty($this->offer['opis'])) ? $this->offer['opis'] : '---'); ?></td>
		<td><?php echo $this->a_wniosek($this->offer['link']); ?></td>
	</tr>
<?php endforeach; ?>
</tbody>