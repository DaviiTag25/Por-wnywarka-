<?php
/**
 * Lista kredyty gotówkowe
 *
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
$showCols = 799; // bez: ubezpieczenie, max okres, oferta doradca
?>
<thead>
	<tr>
		<?php if( $showCols & 1		): ?><th><?php echo $this->descriptions['bank']; ?></th><?php endif; ?>
		<?php if( $showCols & 2		): ?><th><?php echo $this->descriptions['rata']; ?></th><?php endif; ?>
		<?php if( $showCols & 4		): ?><th><?php echo $this->descriptions['prowizja']; ?></th><?php endif; ?>
		<?php if( $showCols & 8		): ?><th><?php echo $this->descriptions['oprocentowanie']; ?></th><?php endif; ?>
		<?php if( $showCols & 16	): ?><th><?php echo $this->descriptions['koszt_calkowity']; ?></th><?php endif; ?>
		<?php if( $showCols & 32	): ?><th><?php echo $this->descriptions['ubezpieczenie_obowiazkowe']; ?></th><?php endif; ?>
		<?php if( $showCols & 64	): ?><th><?php echo $this->descriptions['max_okres_kredytu']; ?></th><?php endif; ?>
		<?php if( $showCols & 128	): ?><th><?php echo $this->descriptions['dostepna_u_doradcy']; ?></th><?php endif; ?>
		<?php if( $showCols & 256	): ?><th><?php echo $this->descriptions['max_kwota_kredytu']; ?></th><?php endif; ?>
		<?php if( $showCols & 512	): ?><th>Wniosek/&shy;Szczegóły</th><?php endif; ?>
	</tr>
</thead>
<tbody>
<?php foreach ($this->results['odpowiedz']['oferty'] as $offer): ?>
	<tr class="singleTr">
		<td>
			<?php 
				$this->offer = $offer;
				echo $this->loadTemplate( 'bankoferta' );
			?>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['rata']; ?></span>
			<span class="unit" ><?php echo $this->units['rata']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['prowizja']; ?></span>
			<span class="unit" ><?php echo $this->units['prowizja']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['oprocentowanie']; ?></span>
			<span class="unit" ><?php echo $this->units['oprocentowanie']; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['koszt_calkowity']; ?></span>
			<span class="unit" ><?php echo $this->units['koszt_calkowity']; ?></span>
		</td>
		<?php if( $showCols & 32	): ?>
		<td>
			<?php echo $this->offer['ubezpieczenie_obowiazkowe']; ?>
		</td>
		<?php endif; ?>
		<?php if( $showCols & 64	): ?>
			<td>
				<span class="value"><?php echo $this->offer['max_okres_kredytu']; ?></span>
				<span class="unit" ><?php echo $this->units['max_okres_kredytu']; ?></span>
			</td>
		<?php endif; ?>
		<?php if( $showCols & 128	): ?>
		<td>
			<?php echo $this->offer['dostepna_u_doradcy']; ?>
		</td>
		<?php endif; ?>
		<td>
			<span class="sayDo">do</span>
			<span class="value"><?php echo $this->offer['max_kwota_kredytu']; ?></span>
			<span class="unit" ><?php echo $this->units['max_kwota_kredytu']; ?>
		</td>
		<td>
			<?php echo $this->a_wniosek($this->offer['link']); ?><br>
			<?php if( 0 && $this->offer['dostepna_u_doradcy'] == 'tak' ): // 0 i cokolwiek = 0 ?>
				<div class="smallT green">Oferta dostępna u doradcy</div>
			<?php endif; ?>
			<?php echo $this->a_szczegoly($this->offer['szczegoly']); ?>
		</td>
	</tr>
<?php endforeach; ?>
</tbody>