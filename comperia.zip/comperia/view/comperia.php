<?php
/**
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

class ComperiaView {
	protected $produkt = '';
	protected $model;
	protected $config;
	protected $tmpl = 'default';
	protected $page_template;
	protected $params;
	protected $title;
	
	public function __construct( $config ){ //ji tu config globalny jako element configa konstruktora klasy, jeśli dziedziczę z JIObject
		$this->produktFilled = false;
		add_action('init', array( $this, 'init') );
		add_action('shutdown', array( $this, 'shutdown') );
		
		add_action('wp_title', array($this,'wp_title' ), 0, PHP_INT_MAX );
		add_filter( 'the_content', array( $this, 'display') );
		add_action( 'wp_enqueue_scripts', array($this,'comperia_style') );
	}
	public function shutdown(){
		ob_get_clean();
	}
	public function init(){
		ob_start();
	}
	public function comperia_style(){
		wp_register_style( 'comperia-style', COMPERIA_URL_PLUGIN . 'media_comperia/css/comperia.css');
		wp_enqueue_style ( 'comperia-style' );
	}
	public function wp_title($title){
		if( is_page() ){
			global $post; 
			$this->fillProdukt();
			if( $post->post_status != 'publish' ){
				return $title;
			}
			if( empty($this->produkt) ){
				return $title;
			}
			return empty($this->title)? $title :$this->title;
		}
		return $title;
	}
	protected function fillProdukt(){
		$this->produktFilled = true;
		global $post; 
		$page = pageOptions::getInstance('pageOptions');
		$page->getValues($post);
		$this->produkt = $page->params->get('produkt','');

		$szczegoly = get_query_var( 'szczegoly' );
	
		$this->config	= &$config;
		$this->params	= comperiaConfig::getInstance('comperiaConfig');
		$_GET['produkt'] = $this->produkt;
		if( !empty($this->produkt) ){
			$pageOptions = $page; // pageOptions::getInstance()
			$existing_comperia_pages = $pageOptions->get_existing_comperia_pages();
			$this->active	= $pageOptions; // pageOptions::getInstance();
			$this->config	= $this->params; // comperiaConfig::getInstance();
			$this->model	= ComperiaModel::getInstance('ComperiaModel');
			
			if( $szczegoly ){
				$this->results = $this->model->szczegoly(SzczegolyParseRoute($szczegoly,$this->produkt))->getResults($this->produkt);
				//nazwa strony do której przypisane są szczegóły
				$this->powrot = $existing_comperia_pages[$this->produkt]->permalink;
				$this->page_template = COMPERIA_PATH_PLUGIN . '/view/szczegoly/' . $this->tmpl;
				if( file_exists( $this->page_template . '.php' ) ){
					ob_start();
					require $this->page_template . '.php';
					$this->comperia_html = ob_get_clean();
					$this->title = ComperiaHelper::$produkty[$this->produkt]['pl'] 
					.' - '. $this->results['odpowiedz']['oferta']['bank']
					.' - '. $this->results['odpowiedz']['oferta']['oferta']
					. ( !empty($this->results['odpowiedz']['seo_title'] ) ? ' ' . $this->results['odpowiedz']['seo_title'] : '' );
				}else{
					// error brak szablonu
				}
			}else{
				$this->form = $this->model->getForm($this->produkt);
				$this->results = $this->model->getResults($this->produkt);
				//wyniki | szczegoly | formularz
				$this->page_template = COMPERIA_PATH_PLUGIN . '/view/lista/' . $this->tmpl;
				if( file_exists( $this->page_template . '.php' ) ){
					ob_start();
					require $this->page_template . '.php';
					$this->comperia_html = ob_get_clean();
				}else{
					// error brak szablonu
				}
			}
			
		}
	}
	public function display($content){
		if(!$this->produktFilled){
			$this->fillProdukt();
		}
		if( !empty($this->comperia_html) ){
			if( preg_match('/\[comperia\]/', $content, $matches) ){
				$content = preg_replace('/\[comperia\]/', $this->comperia_html, $content);
			}else{
				$content .= $this->comperia_html;
			}
			wp_enqueue_script(
				 'comepria'
				,COMPERIA_URL_PLUGIN.'media_comperia/js/comperia.js'
				,array( 'jquery' )
			);
		}
		return $content;
	}
	public function getForm()
	{
		if($this->params->get('showForm',1)){
			return $this->model->generateForm($this->form);
		}
		return '';
	}
	public function responseExist(){
		return (isset($this->results['odpowiedz']) && is_array($this->results['odpowiedz']) && !empty($this->results['odpowiedz']['oferty']));
	}
	protected function a_wniosek( $href, $anchor = null ){
		$target = $this->params->get('lead_target','_popup');
		$anchor = $anchor !== null ? $anchor : $this->params->get('wniosek','Dalej');
		$targetAttr = ComperiaHelper::gettargetAttr($target,$href);
		
		$layout = $this->params->get('lead_layout','');
		$layout .= $this->params->get('lead_round','');
		return '<a ' . $targetAttr . ' rel="nofollow" class="wniosek'.$layout.'" href="' . $href . '">' . $anchor . '</a>';
	}
	protected function a_szczegoly( $uriString ){
		$pageOptions = pageOptions::getInstance('pageOptions');
		$existing_comperia_pages = $pageOptions->get_existing_comperia_pages();
		parse_str($uriString,$uriVariables);
		$target = $this->params->get('szczegoly_target','_self');
		$produkt_permalink = $existing_comperia_pages[$uriVariables['produkt']]->permalink;
		if( get_option('permalink_structure', '') ){ //posiadamy jakąś strukturę
			$href = trailingslashit($produkt_permalink) . trailingslashit(SzczegolyBuildRoute($uriVariables));
		}else{ //nie ma struktury permalinków - wszytko w $_GET
			$produkt_permalink = parse_url($produkt_permalink);
			parse_str( $produkt_permalink['query'], $produkt_query);
			$produkt_permalink['query'] = http_build_query(
				array_merge(
					 $produkt_query
					,array('szczegoly' => SzczegolyBuildRoute($uriVariables))
				)
			);
			$produkt_permalink['query'] = empty($produkt_permalink['query']) ? '' : '?' . $produkt_permalink['query'] ;
			$href = $produkt_permalink['scheme'] .'://'. $produkt_permalink['host'] . $produkt_permalink['path'] . $produkt_permalink['query'];
			
		}
		$targetAttr = ComperiaHelper::gettargetAttr($target,$href);
		$anchor = $this->params->get('szczegoly','Szczegóły');
		return '<a ' . $targetAttr . 'class="szczegoly" href="' . $href . '">' . $anchor . '</a>';
	}
	protected function loadTemplate( $suffix ){
		ob_start();
		require $this->page_template . '_' . $suffix . '.php';
		return ob_get_clean();
	}
	public function getPM($descriptions,$offer){
		ob_start();
		?>
		<?php if ( !empty($offer['plusy']) ): ?>
		<div>
		<b><?php echo $descriptions['plusy']; ?></b>:
			<?php if (is_array($offer['plusy'])): ?>
				<ul>
				<?php foreach ($offer['plusy'] as $plus): ?>
					<li><?php echo $plus; ?></li>
				<?php endforeach; ?>
				</ul>
			<?php else: ?>
				<?php echo $offer['plusy']; ?>
			<?php endif; ?>
		</div>
		<?php endif; ?>
		<?php if ( !empty($offer['minusy']) ): ?>
		<div>
			<b><?php echo $descriptions['minusy']; ?></b>:
			<?php if (is_array($offer['minusy'])): ?>
				<ul>
				<?php foreach ($offer['minusy'] as $minus): ?>
					<li><?php echo $minus; ?></li>
				<?php endforeach; ?>
				</ul>
			<?php else: ?>
				<?php echo $offer['minusy']; ?>
			<?php endif; ?>
		</div>
		<?php endif; ?>
		<?php
		return ob_get_clean();
	}
	
}