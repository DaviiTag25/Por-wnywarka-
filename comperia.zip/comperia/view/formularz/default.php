<?php
/**
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

?>
<div id="widget_comperia_<?php echo $this->produkt; ?>" class="widget widget_comperia">
	<h3><?php echo $this->title; ?></h3>
	<div class="comperiaForm">
		<?php // echo '<pre>'.print_r($this->form,true).'</pre>'; ?>
		<?php // foreach($this->form['odpowiedz']['formularz']): ?>
		<?php echo $this->model->generateForm($this->response, $this->produkt ); ?>
		<?php // foreach(): ?>
	</div>
</div>