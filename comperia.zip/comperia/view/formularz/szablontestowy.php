<?php
/**
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * Istnieje możliwość stworzenia własnego szablonu, aby to zrobić należy skopiować ten plik nadając mu inną nazwę. 
 * Plik szablonu wybiera się w ustawieniach widgeta.
 * Szczegóły konstrukcji formularza są w funkcji comperiaModel::generateForm()
 * Obiekt modelu dostępny z poziomu $this->model
 */
?>
<div id="widget_comperia_<?php echo $this->produkt; ?>" class="widget widget_comperia">
	<h1>Szablon alternatywny!</h1>
	<p>Szczegóły dostępne w wp-content/plugins/comperia/view/formularz/, albo odpowiedniku</p>
	<h3><?php echo $this->title; ?></h3>
	<div class="comperiaForm">
		<?php echo $this->model->generateForm($this->response, $this->produkt ); ?>
	</div>
</div>