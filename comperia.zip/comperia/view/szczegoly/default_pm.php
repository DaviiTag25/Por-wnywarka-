<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<?php if ( !empty($this->offer['plusy']) ): ?>
	<thead>
		<tr>
			<th colspan="3"><?php echo $this->descriptions['plusy']; ?></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td colspan="3">
					<ul>
				<?php if ( is_array($this->offer['plusy']) ): ?>
					<?php foreach ($this->offer['plusy'] as $plus): ?>
						<li><?php echo $plus; ?></li>
					<?php endforeach; ?>
					</ul>
				<?php else: ?>
					<?php echo $offer['plusy']; ?>
				<?php endif; ?>
			</td>
		</tr>
	</tbody>
<?php endif; ?>
<?php if ( !empty($this->offer['minusy']) ): ?>
	<thead>
		<tr>
			<th colspan="3"><?php echo $this->descriptions['minusy']; ?></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td colspan="3">
					<ul>
				<?php if ( is_array($this->offer['minusy']) ): ?>
					<?php foreach ($this->offer['minusy'] as $plus): ?>
						<li><?php echo $plus; ?></li>
					<?php endforeach; ?>
					</ul>
				<?php else: ?>
					<?php echo $offer['plusy']; ?>
				<?php endif; ?>
			</td>
		</tr>
	</tbody>
<?php endif; ?>