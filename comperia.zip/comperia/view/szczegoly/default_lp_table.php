<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<thead>
	<tr>
		<th colspan="3"><?php echo $this->descriptions['koszt_miesieczny_nazwy']; ?></th>
	</tr>
</thead>
<tbody>
	<?php foreach ($this->offer['koszt_miesieczny_nazwy'] as $key => $nazwa): ?>
	<tr>
		<td><?php echo $nazwa; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['koszt_miesieczny_wartosci'][$key]; ?></span>
			<span class="unit" ><?php echo $this->offer['koszt_miesieczny_jednostki'][$key]; ?></span>
		</td>
		<td><?php echo $this->offer['koszt_miesieczny_komentarze'][$key]; ?></td>
	</tr>
	<?php endforeach?>
</tbody>
<thead>
	<tr>
		<th colspan="3"><?php echo $this->descriptions['dodatkowe_informacje']; ?></th>
	</tr>
</thead>
<tbody>
	<tr>
		<td colspan="3">
			<?php if (isset($this->offer['dodatkowe_informacje'])): ?>
				<?php if (is_array($this->offer['dodatkowe_informacje']) && !empty($this->offer['dodatkowe_informacje'])): ?>
					<ul>
					<?php foreach ($this->offer['dodatkowe_informacje'] as $inf): ?>
						<li><?php echo $inf; ?></li>
					<?php endforeach; ?>
					</ul>
				<?php else: ?>
					<?php echo $this->offer['dodatkowe_informacje']; ?>
				<?php endif; ?>
			<?php else: ?>
				<?php echo 'brak dodatkowych informacji'; ?>
			<?php endif; ?>
		</td>
	</tr>
</tbody>