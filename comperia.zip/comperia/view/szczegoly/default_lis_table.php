<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<thead>
	<tr>
		<th colspan="4"><?php echo $this->descriptions['koszt_obslugi_nazwa']; ?></th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><?php echo $this->offer['koszt_obslugi_nazwa']; ?></td>
		<td colspan="2">
			<span class="value"><?php echo $this->offer['koszt_obslugi_wartosc']; ?></span>
			<span class="unit" ><?php echo $this->offer['koszt_obslugi_jednostka']; ?></span>
		</td>
		<td><?php echo $this->offer['koszt_obslugi_komentarz']; ?></td>
	</tr>
</tbody>
<thead>
	<tr>
		<th colspan="4"><?php echo $this->descriptions['oplaty_nazwy']; ?></th>
	</tr>
</thead>
<tbody>
	<?php foreach ($this->offer['oplaty_nazwy'] as $key => $nazwa): ?>
	<tr>
		<td><?php echo $nazwa; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['oplaty_wartosci_procentowe'][$key]; ?></span>
			<span class="unit" ><?php echo $this->offer['oplaty_jednostki_procentowe'][$key]; ?></span>
		</td>
		<td>
			<span class="value"><?php echo $this->offer['oplaty_wartosci_kwotowe'][$key]; ?></span>
			<span class="unit" ><?php echo $this->offer['oplaty_jednostki_kwotowe'][$key]; ?></span>
		</td>
		<td><?php echo $this->offer['oplaty_komentarze'][$key]; ?></td>
	</tr>
	<?php endforeach; ?>
</tbody>
<thead>
	<tr>
		<th colspan="4">Dodatkowe informacje</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td colspan="3"><?php echo $this->descriptions['rodzaj_zabezpieczenia']; ?></td>
		<td><?php echo $this->offer['rodzaj_zabezpieczenia']; ?></td>
	</tr>
	<tr>
		<td colspan="3"><?php echo $this->descriptions['amortyzacja']; ?></td>
		<td><?php echo $this->offer['amortyzacja']; ?></td>
	</tr>
	<tr>
		<td colspan="3"><?php echo $this->descriptions['dodatkowe_wymagania']; ?></td>
		<td>
			<?php if (isset($this->offer['dodatkowe_informacje'])): ?>
				<?php if (is_array($this->offer['dodatkowe_informacje']) && !empty($this->offer['dodatkowe_informacje'])): ?>
				<ul>
				<?php foreach ($this->offer['dodatkowe_informacje'] as $inf): ?>
					<li><?php echo $inf; ?></li>
				<?php endforeach; ?>
				</ul>
				<?php else: ?>
					<?php echo $this->offer['dodatkowe_informacje']; ?>
				<?php endif; ?>
			<?php else: ?>
				brak dodatkowych informacji
			<?php endif; ?>
		</td>
	</tr>
</tbody>
<?php echo $this->loadTemplate( 'pm' ); // leasing nie posiada obecnie info w tym widoku ?>