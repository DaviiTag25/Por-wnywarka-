<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<thead>
	<tr>
		<th colspan="3"><?php echo $this->descriptions['koszt_miesieczny_nazwy']; ?></th>
	</tr>
</thead>
<tbody>
	<?php foreach ( $this->offer['koszt_miesieczny_nazwy'] as $key => $nazwa ): ?>
	<tr>
		<td><span class="trait"><?php echo $nazwa; ?></span></td>
		<td>
			<span class="value"><?php echo $this->offer['koszt_miesieczny_wartosci'][$key]; ?></span>
			<span class="unit"><?php echo $this->offer['koszt_miesieczny_jednostki'][$key]; ?></span>
		</td>
		<td><?php echo $this->offer['koszt_miesieczny_komentarze'][$key]; ?></td>
	</tr>
	<?php endforeach; ?>
</tbody>
<thead>
	<tr>
		<th colspan="3"><?php echo $this->descriptions['koszt_przyznania_nazwy']; ?></th>
	</tr>
</thead>
<tbody>
	<?php foreach ( $this->offer['koszt_przyznania_nazwy'] as $key => $nazwa ): ?>
	<tr>
		<td><span class="trait"><?php echo $nazwa; ?></span></td>
		<td>
			<span class="value"><?php echo $this->offer['koszt_przyznania_wartosci'][$key]; ?></span>
			<span class="unit"><?php echo $this->offer['koszt_przyznania_jednostki'][$key]; ?></span>
		</td>
		<td><?php echo $this->offer['koszt_przyznania_komentarze'][$key]; ?></td>
	</tr>
	<?php endforeach; ?>
	<tr class="suma important">
		<td><?php echo $this->descriptions['suma_kosztow']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['suma_kosztow']; ?></span>
			<span class="unit"><?php echo $this->units['suma_kosztow']; ?></span>
		</td>
		<td>&nbsp;</td>
	</tr>
</tbody>
<thead>
	<tr>
		<th colspan="3"><?php echo $this->descriptions['dodatkowe_informacje_nazwy']; ?></th>
	</tr>
</thead>
<tbody>
	<?php foreach ($this->offer['dodatkowe_informacje_nazwy'] as $key => $name): ?>
	<tr>
		<td><span class="trait"><?php echo $nazwa; ?></span></td>
		<td>
			<span class="value"><?php echo $this->offer['dodatkowe_informacje_wartosci'][$key]; ?></span>
			<span class="unit"><?php echo $this->offer['dodatkowe_informacje_jednostki'][$key]; ?></span>
		</td>
		<td><?php echo $this->offer['dodatkowe_informacje_komentarze'][$key]; ?></td>
	</tr>
	<?php endforeach; ?>
</tbody>
<thead>
	<tr>
		<th colspan="3"><?php echo $this->descriptions['przewalutowanie_wartosci']; ?></th>
	</tr>
</thead>
<tbody>
	<?php foreach ($this->offer['przewalutowanie_wartosci'] as $key => $value): ?>
	<tr clas="przewalutowanie">
		<td class="value" colspan="2"><?php echo $value; ?></td>
		<td class="comments"><?php echo $this->offer['przewalutowanie_komentarze'][$key]; ?></td>
	</tr>
	<?php endforeach; ?>
</tbody>
<?php echo $this->loadTemplate( 'pm' ); ?>