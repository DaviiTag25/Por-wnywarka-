<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<?php echo $this->loadTemplate( 'bank' ); ?>
<div class="topQuickDetails">
	<p class="marza">
		<span class="trait"><?php echo $this->descriptions['marza']; ?>: </span>
		<span class="value"><?php echo $this->offer['marza']; ?></span>
		<span class="unit"><?php echo ( !in_array($this->offer['marza'],array('negocjowana','') )
		? $this->units['marza'] : ''); ?></span>
	</p>
	<p class="prowizja">
		<span class="trait"><?php echo $this->descriptions['prowizja']; ?>: </span>
		<span class="value"><?php echo $this->offer['prowizja']; ?></span>
		<span class="unit"><?php echo ( !in_array($this->offer['prowizja'],array('negocjowana','')) 
		? $this->units['prowizja'] : ''); ?></span>
	</p>
</div>