<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<?php echo $this->loadTemplate( 'bank' ); ?>
<div class="topQuickDetails">
	<p class="poziomOchrony">
		<span class="trait"><?php echo $this->descriptions['poziom_ochrony_kapitalu']; ?>: </span>
		<span class="value"><?php echo $this->offer['poziom_ochrony_kapitalu']; ?></span>
		<span class="unit"><?php echo $this->units['poziom_ochrony_kapitalu']; ?></span>
	</p>
	<p class="koniecSubskrypcji">
		<span class="trait"><?php echo $this->descriptions['koniec_subskrypcji']; ?>: </span>
		<span class="value"><?php echo $this->offer['koniec_subskrypcji']; ?></span>
		<span class="unit"><?php echo $this->units['koniec_subskrypcji']; ?></span>
	</p>
	<p class="oplatyWstepne">
		<span class="trait"><?php echo $this->descriptions['oplaty_wstepne']; ?>: </span>
		<span class="value"><?php echo $this->offer['oplaty_wstepne']; ?></span>
		<span class="unit"><?php echo $this->units['oplaty_wstepne']; ?></span>
	</p>
</div>