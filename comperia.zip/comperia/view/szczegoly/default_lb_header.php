<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<?php echo $this->loadTemplate( 'bank' ); ?>
<div class="topQuickDetails">
	<p class="odsetkiPrzed">
		<span class="trait"><?php echo $this->descriptions['odsetki_przed_opodatkowaniem']; ?>: </span>
		<span class="value"><?php echo $this->offer['odsetki_przed_opodatkowaniem']; ?></span>
		<span class="unit"><?php echo $this->units['odsetki_przed_opodatkowaniem']; ?></span>
	</p>
	<p class="odsetkiPo">
		<span class="trait"><?php echo $this->descriptions['odsetki_po_podatku']; ?>: </span>
		<span class="value"><?php echo $this->offer['odsetki_po_podatku']; ?></span>
		<span class="unit"><?php echo $this->units['odsetki_po_podatku']; ?></span>
	</p>
	<p class="oprocentowanie">
		<span class="trait"><?php echo $this->descriptions['oprocentowanie']; ?>: </span>
		<span class="value"><?php echo $this->offer['oprocentowanie']; ?></span>
		<span class="unit"><?php echo $this->units['oprocentowanie']; ?></span>
	</p>
</div>