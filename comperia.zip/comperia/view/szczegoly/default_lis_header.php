<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<?php echo $this->loadTemplate( 'bank' ); ?>
<div class="topQuickDetails">
	<p class="rataMiesieczna">
		<span class="trait"><?php echo $this->descriptions['rata_miesieczna']; ?>: </span>
		<span class="value"><?php echo $this->offer['rata_miesieczna']; ?></span>
		<span class="unit" ><?php echo $this->units['rata_miesieczna']; ?></span>
	</p>
	<p class="czynsz">
		<span class="trait"><?php echo $this->descriptions['czynsz']; ?>: </span>
		<span class="value"><?php echo $this->offer['czynsz']; ?></span>
		<span class="unit" ><?php echo $this->units['czynsz']; ?></span>
	</p>
	<p class="sumaOplat">
		<span class="trait"><?php echo $this->descriptions['suma_oplat']; ?>: </span>
		<span class="value"><?php echo $this->offer['suma_oplat']; ?></span>
		<span class="unit" ><?php echo $this->units['suma_oplat']; ?></span>
	</p>
</div>