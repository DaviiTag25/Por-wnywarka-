<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<div class="topBankInfo">
	<p class="bank">
		<a <?php echo ComperiaHelper::gettargetAttr($this->params->get('lead_target','_popup'),$this->offer['link']); ?>>
			<?php if(isset($this->offer['logotyp']) && !empty($this->offer['logotyp'])): 
			$bank = htmlspecialchars($this->offer['bank']);
			?>
				<img class="logoBank" src="<?php echo htmlspecialchars($this->offer['logotyp']); ?>" title="<?php echo $bank; ?>" alt="<?php echo $bank; ?>">
			<?php else: ?>
				<strong><?php echo $this->offer['bank']; ?></strong>
			<?php endif; ?>
		</a>
	</p>
	<?php if( isset( $this->offer['oferta'] ) ): ?>
		<p class="oferta"><?php echo $this->offer['oferta']; ?></p>
	<?php endif; ?>
</div>
