<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<?php echo $this->loadTemplate( 'bank' ); ?>
<div class="topQuickDetails">
	<p class="rata">
		<span class="trait"><?php echo $this->descriptions['rata']; ?>: </span>
		<span class="value"><?php echo $this->offer['rata']; ?></span>
		<span class="unit"><?php echo $this->units['rata']; ?></span>
	</p>
	<p class="oprocentowanie">
		<span class="trait"><?php echo $this->descriptions['oprocentowanie']; ?>: </span>
		<span class="value"><?php echo $this->offer['oprocentowanie']; ?></span>
		<span class="unit"><?php echo $this->units['oprocentowanie']; ?></span>
	</p>
	<p class="prowizja">
		<span class="trait"><?php echo $this->descriptions['prowizja']; ?>: </span>
		<span class="value"><?php echo $this->offer['prowizja']; ?></span>
		<span class="unit"><?php echo $this->units['prowizja']; ?></span>
	</p>
</div>