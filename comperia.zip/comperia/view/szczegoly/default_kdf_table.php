<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<thead>
	<tr>
		<th colspan="3">Opis oferty</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><?php echo $this->descriptions['wartosc_kredytu_max']; ?></td>
		<td><?php
			if (isset($this->offer['wartosc_kredytu_max'])) {
			echo $this->offer['wartosc_kredytu_max'] . ' '
			. (($this->offer['wartosc_kredytu_max'] !== 'negocjowana' &&  $this->offer['wartosc_kredytu_max'] !== '') ? $this->units['wartosc_kredytu_max'] : '');
			} ?>
		</td>
		<td><?php echo $this->offer['wartosc_kredytu_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['okres_dzialalnosci_firmy_min']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['okres_dzialalnosci_firmy_min']; ?></span>
			<span class="unit" ><?php echo $this->units['okres_dzialalnosci_firmy_min']; ?></span>
		</td>
		<td><?php echo $this->offer['okres_dzialalnosci_firmy_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['przeznaczenie_kredytu_komentarz']; ?></td>
		<td>&nbsp;</td>
		<td><?php echo $this->offer['przeznaczenie_kredytu_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['dla_kogo_kredyt_komentarz']; ?></td>
		<td>&nbsp;</td>
		<td><?php echo $this->offer['dla_kogo_kredyt_komentarz']; ?></td>
	</tr>
</tbody>
<thead>
	<tr>
		<th colspan="3">Koszt kredytu</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><?php echo $this->descriptions['min_marza']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['marza']; ?></span>
			<span class="unit" ><?php echo (!in_array($this->offer['marza'] , array('negocjowana','')) ? $this->units['marza'] : ''); ?></span>
		</td>
		<td rowspan="4"><?php echo $this->offer['marza_komentarz_do_szczegolow']; ?></td>
	</tr>
	<tr class="lastNormal">
		<td><?php echo $this->descriptions['oprocentowanie_nominalne']; ?></td>
		<td>
			<?php if (isset($this->offer['oprocentowanie_nominalne']) && $this->offer['oprocentowanie_nominalne'] != ''): ?>
				<span class="value"><?php echo $this->offer['oprocentowanie_nominalne']; ?></span>
				<span class="unit" ><?php echo $this->units['oprocentowanie_nominalne']; ?></span>
			<?php endif; ?>
		</td>
	</tr>
	<tr class="lastNormal">
		<td><?php echo $this->descriptions['oprocentowanie_rzeczywiste']; ?></td>
		<td>
			<?php if (isset($this->offer['oprocentowanie_rzeczywiste']) && $this->offer['oprocentowanie_rzeczywiste'] != ''): ?>
				<span class="value"><?php echo $this->offer['oprocentowanie_rzeczywiste']; ?></span>
				<span class="unit" ><?php echo $this->units['oprocentowanie_rzeczywiste']; ?></span>
			<?php endif; ?>
		</td>         
	</tr>
	<tr class="lastNormal">
		<td><?php echo $this->descriptions['rata_miesieczna']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['rata_miesieczna']; ?></span>
			<span class="unit" ><?php echo $this->units['rata_miesieczna']; ?></span>
		</td> 
	</tr>
	<tr>
		<td><?php echo $this->descriptions['prowizja_za_rozpatrzenie']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['prowizja_za_rozpatrzenie']; ?></span>
			<span class="unit" ><?php echo $this->units['prowizja_za_rozpatrzenie']; ?></span>
		</td>
		<td><?php echo $this->offer['prowizja_za_rozpatrzenie_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['prowizja_przygotowawcza']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['prowizja_przygotowawcza']; ?></span>
			<span class="unit" ><?php echo $this->units['prowizja_przygotowawcza']; ?></span>
		</td>
		<td><?php echo $this->offer['prowizja_przygotowawcza_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['prowizja_od_niewykorzystanych_srodkow']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['prowizja_od_niewykorzystanych_srodkow']; ?></span>
			<span class="unit" ><?php echo $this->units['prowizja_od_niewykorzystanych_srodkow']; ?></span>
		</td>
		<td><?php echo $this->offer['prowizja_od_niewykorzystanych_srodkow_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['wczesniejsza_splata']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['wczesniejsza_splata']; ?></span>
			<span class="unit" ><?php echo $this->units['wczesniejsza_splata']; ?></span>
		</td>
		<td><?php echo $this->offer['wczesniejsza_splata_komentarz']; ?></td>
	</tr>
</tbody>
<thead>
	<tr>
		<th colspan="3">Dodatkowe informacje</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td><?php echo $this->descriptions['podstawa_przyznania']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['podstawa_przyznania']; ?></span>
			<span class="unit" ><?php echo $this->units['podstawa_przyznania']; ?></span>
		</td>
		<td><?php echo $this->offer['podstawa_przyznania_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['zabezpieczenie_kredytu']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['zabezpieczenie_kredytu']; ?></span>
			<span class="unit" ><?php echo $this->units['zabezpieczenie_kredytu']; ?></span>
		</td>
		<td><?php echo $this->offer['zabezpieczenie_kredytu_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['odnawialnosc']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['odnawialnosc']; ?></span>
			<span class="unit" ><?php echo $this->units['odnawialnosc']; ?></span>
		</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['ubezpieczenie']; ?></td>
		<td>
			<span class="value"><?php echo $this->offer['ubezpieczenie']; ?></span>
			<span class="unit" ><?php echo $this->units['ubezpieczenie']; ?></span>
		</td>
		<td><?php echo $this->offer['ubezpieczenie_komentarz']; ?></td>
	</tr>
	<tr>
		<td><?php echo $this->descriptions['forma_rozliczenia_us_komentarz']; ?></td>
		<td>&nbsp;</td>
		<td><?php echo $this->offer['forma_rozliczenia_us_komentarz']; ?></td>
	</tr>
</tbody>
<?php echo $this->loadTemplate( 'pm' ); ?>