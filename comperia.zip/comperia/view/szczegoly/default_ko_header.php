<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<?php echo $this->loadTemplate( 'bank' ); ?>
<div class="topQuickDetails">
	<p class="odsetkiPo">
		<span class="trait"><?php echo $this->descriptions['odsetki_po_podatku']; ?>: </span>
		<span class="value"><?php echo $this->offer['odsetki_po_podatku']; ?></span>
		<span class="unit" ><?php echo $this->units['odsetki_po_podatku']; ?></span>
	</p>
	<p class="odsetkiPrzed">
		<span class="trait"><?php echo $this->descriptions['koszt_uzytkowania']; ?>: </span>
		<span class="value"><?php echo $this->offer['koszt_uzytkowania']; ?></span>
		<span class="unit" ><?php echo $this->units['koszt_uzytkowania']; ?></span>
	</p>
	<p class="oplataProwadzenie">
		<span class="trait"><?php echo $this->descriptions['oplata_za_prowadzenie']; ?>: </span>
		<span class="value"><?php echo $this->offer['oplata_za_prowadzenie']; ?></span>
		<span class="unit" ><?php echo $this->units['oplata_za_prowadzenie']; ?></span>
	</p>
</div>