<?php
/**
 * @package     Comperia
 * @subpackage	com_comperia
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
?>
<div id="com_comperia">
	<div id="ComperiaDetails_<?php echo $this->produkt; ?>" class="ComperiaDetails">
		<?php if (isset($this->results['odpowiedz']) && is_array($this->results['odpowiedz'])):
			 $this->units = $this->results['odpowiedz']['jednostki'];
			 $this->offer = $this->results['odpowiedz']['oferta'];
			 $this->descriptions = $this->results['odpowiedz']['opisy'];
		?>
			<h2><?php echo $this->params->get('page_title', $this->offer['bank'] . ' ' . $this->offer['oferta']); ?></h2>
			<?php if($this->active->params->get('tekst_szczegoly_top','')): ?>
				<div class="textTop"><p><?php echo $this->active->params->get('tekst_list_top'); ?></p></div>
			<?php endif; ?>

			<div class="comperiaContainer">
				<div class="topInfo">
					<?php echo $this->loadTemplate( $this->produkt . '_header' ); ?>
					<div class="wniosekContainer"><?php echo $this->a_wniosek($this->offer['link']); ?></div>
				</div>
				<table class="ComperiaDetailsTable" border="1" cellpadding="0" cellspacing="0">
					<colgroup>
						<col span="1" class="trait">
						<col span="<?php echo in_array($this->produkt,array('lis'))?'2':1; ?>" class="value">
						<col span="1" class="description">
					 </colgroup>
					<?php echo $this->loadTemplate( $this->produkt . '_table' ); ?>
				</table>
				<div class="bottomInfo">
					<div class="wniosekContainer">
						<?php echo ComperiaHelper::stopka( $this->results ); ?>
						<?php if( $this->params->get('szczegoly_powrot',0) ): ?>
							<a class="powrot" title="<?php echo ComperiaHelper::$productsPol[$this->produkt]; ?>" href="<?php echo $this->powrot; ?>">
								Powrót
							</a>
						<?php endif; ?>
						<?php echo $this->a_wniosek($this->offer['link']); ?>
					</div>
				</div>
			</div>
			<?php if($this->active->params->get('tekst_szczegoly_bottom','')): ?>
				<div class="textBottom"><p><?php echo $this->active->params->get('tekst_list_bottom'); ?></p></div>
			<?php endif; ?>
		<?php else: ?>
			<?php if( !$this->responseExist() ): ?>
				<?php echo '<p>'.( $this->model->error ? $this->model->error : 'Brak wyników' ).'</p>'; ?>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<!--[if IE 6]>
	<style>
		filter:none;
	</style>
	<![endif]-->
</div>