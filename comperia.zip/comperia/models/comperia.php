<?php
/**
 * @copyright	Copyright (C) 2013 Comperia S.A. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

class ComperiaModel extends JIObject
{
	protected $mainparams = array();
	protected $produkt;
	protected $params;
	protected $response;
	protected $cacheFolder;
	protected $conf;
	protected static $instances = 0;
	protected $instance;
	public $error; // dla 404
	
	public function __construct( $conf = array() ){
		$this->instance = self::$instances;
		self::$instances++;
		$this->conf								= $conf;
		$this->produkt							= JFactory::getApplication()->input->get('produkt','');
		$this->cacheFolder					= COMPERIA_PATH_PLUGIN . '/cache/';
		if (!file_exists($this->cacheFolder) and !is_dir($this->cacheFolder)) {
			mkdir($this->cacheFolder);
		} 
		$this->params = comperiaConfig::getInstance('comperiaConfig');

		$this->mainparams['format']		= $this->params->get('format');
		$this->mainparams['polecenie']	= 'wyniki';
		$this->mainparams['ilosc']			= $this->params->get('limit');
		$this->mainparams['strona']		= 1;
		parent::__construct( $conf );
	}
	
	public function getForm( $produkt = null, $additionalParams = array(), $throwError = true )
	{
		if( empty($produkt) ) return array();
		if( !in_array( $produkt,array('pzb')) ){ // pzb nie ma formularza
			$mainparams['format']		= $this->params->get('format');
			$mainparams['polecenie']	= 'formularz';
			$productparams['produkt']	= $produkt;
			$params = array_merge($mainparams, $productparams);
			$params = array_merge($params, $additionalParams);
			return $this->comperiaLeadApi( ComperiaHelper::getApi(), $params, $throwError );
		}else{
			return array();
		}
	}
	
	public function szczegoly( $routedParams ){
		$this->mainparams['polecenie']	= 'szczegoly';
		$this->mainparams = array_merge($this->mainparams, $routedParams);
		
		return $this;
	}
	
	public function getResults( $produkt = '' )
	{
		if( empty($produkt) ){
			return array();
		}else{
			//ji tu ARgumenty
			$params['produkt'] = $produkt;
			$productparams = array(
				'produkt' => $produkt
				// ,'argumenty' => 'array'
				// ,'id_oferty' => 'int'
			);
			 // $productparams = JRequest::get('get');
			$params = array_merge($this->mainparams, $productparams);
			return $this->comperiaLeadApi( ComperiaHelper::getApi(), $params );
		}
	}
	
	protected function classifyCss($classes){
		if( $classes !== '' ){
			return ' class="' . $classes . '"';
		}else{
			return '';
		}
	}
	
	/**
	 *	domyślna metoda generowania formularza //można przenieść do widoku, jeśli tam też będę dziedziczył
	 *
	 */
	function generateForm($form = null, $produkt = null){
		static $unique=0; // aby każdy formularz był unikatowy
		$unique++;
		if($form === null){ $form = $this->getForm(); }
		if( !isset($form['odpowiedz']['formularz']) ){
			return'';
		}
		if($produkt === null){// na wypadek, gdyby nie był podany produkt,
			foreach ( $form['odpowiedz']['formularz'] as $field ) {// szukamy go w formularzu pobranym z API
				if($field['name'] == 'produkt'){ $produkt = $field['value']; break; }
			}
		}
		$pageOptions = pageOptions::getInstance('pageOptions');
		$existing_comperia_pages = $pageOptions->get_existing_comperia_pages();
		$r  = '';
		$tmpl = '';
		$target = '';
		$script = '';
		$id = 'comperiaForm_'.$produkt.'_'.$unique;
		if($this->params->get('wyniki_target','_self') == '_popup'){
			// $tmpl = '?tmpl=component';
			$target = ' target="popup"';
			$script = '
			<script>
				var myForm_'.$unique.' = document.getElementById("'.$id.'");
				myForm_'.$unique.'.onsubmit = function() {
					 var w = window.open("about:blank","Popup_Window","toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0");
					 this.target = "Popup_Window";
				};
			</script>
			';
		}else if($this->params->get('wyniki_target','_self') == '_blank'){
			$target = ' target="_blank"';
		}

		$action = $existing_comperia_pages[$produkt]->permalink . $tmpl;
		// $r .= $action;
		$r .= '<form id="'.$id.'" class="comperiaForm" method="post" action="'. $action .'" ' . $target . '>';
		$getModified = array();

		if( $existing_comperia_pages[$produkt]->produkt == $produkt ){
			$argumenty = JFactory::getApplication()->input->get('argumenty',array(),'array');
			if ( !empty($argumenty) ) {
				foreach ($argumenty as $key => $val) {
					$getModified['argumenty[' . $key . ']'] = $val;
				}
			}
		}
		$first = true;
		$i = 0;
		foreach ( $form['odpowiedz']['formularz'] as $field ) {
			if( $field['name'] == 'p' ){continue;}
			if ( 'input' === $field['tag'] && 'hidden' === $field['type']) {
				 $r .=  '<input type="hidden" name="' . $field['name'] . '" value="' . $field['value'] . '">';
			}else{
				$class		= '';
				$rowClass	= '';
				if (isset($field['size'])) {
					if ($field['size'] === 's') {
						$class = 'field_short';
					} else if ($field['size'] === 'm') {
						$class = 'field_medium';
					} else if ($field['size'] === 'l') {
						$class = 'field_long';
					}
				}
				if( isset($field['unit']) && $field['unit'] ){
					$class .= ' hasUnit';
				}else{
					$class .= ' noUnit';
				}
				if( $first ){
					$rowClass .= ' first';
					$first = false;
				}else if( $i == count( $form['odpowiedz'] ) - 1 ){
					$rowClass .= ' last';
				}else{
					$rowClass .= ' row';
				}
				$class		= $this->classifyCss($class);
				$rowClass	= $this->classifyCss($rowClass);

				$r .=  '<p'.$rowClass.'>';
				$r .=  '<label>' . $field['label'] . '</label>';
				if ('input' === $field['tag']) {
					$r .= '<input'.$class.' type="text" name="' . $field['name'] . '" '
					. 'value="' . (isset($getModified[$field['name']]) ? $getModified[$field['name']] : $field['value']) . '">';
				}
				if ('select' === $field['tag']) {
					$r .=  '<select'.$class.' name="' . $field['name'] . '">';
					foreach ($field['options'] as $option) {
						$r .=  '<option value="' . $option['value'] . '" '
							. ((int)$option['value'] === (int)(isset($getModified[$field['name']])
								? $getModified[$field['name']] : $field['value'])
							? 'selected="selected"' : '')
							. '>' . $option['label'] . '</option>';
					}
					$r .=  '</select>';
				}
				if( $field['unit'] ){
					$r .= '<span class="unit">' . $field['unit'] . '</span>';
				}
				$r .=  '</p>';
			}
			$i++;
		}
		$r .= '<p class="actions">';
		$r .= ComperiaHelper::stopka( $this->response );
		$r .= '<input type="submit" class="submit" value="'.$this->params->get('wyslij','szukaj').'">';
		$r .= '</p>';
		$r .= $script;
		$r .= '</form>';
		return $r;
	}
	
	function comperiaLeadApi( $apiKey, $params, $throwError = true ){
		$clApiUrl = ComperiaHelper::getApiUrl();
		$params['api'] = $apiKey;
		$params['host'] = $_SERVER['HTTP_HOST'];

		$post = $_REQUEST;
		$pageOptions = pageOptions::getInstance('pageOptions');
		if( isset($post['argumenty']) && is_array($post['argumenty']) && $pageOptions->params->get('produkt','') == $params['produkt']){
			$params['argumenty'] = $post['argumenty'];
		}
		if( !isset( $params['nolink'] ) ){
			$params['nolink'] = $this->params->get('nolink',0);
		}
		global $wp_version;
		
		$params = array_merge($params, array(
			 'u_platform' => 'Wordpress'
			,'u_platform_version' => $wp_version
			,'u_version' => $this->getExtensionVersion('comperia')
		));
		// echo '<pre>'.print_r($params,true).'</pre>';die;
		// koniec ustawiania parametrów
		$md5 = md5(serialize($params));
		$cacheFilename = $params['produkt'] . '-' . $params['polecenie'] . '-' . $md5 . '.obj';
		$cacheFilepath = $this->cacheFolder . $cacheFilename;
		
		$cacheExists = false;
		if( $this->params->get( 'cacheTime', 86200 ) != -1 ){
			if( file_exists( $cacheFilepath ) ){
				if( (time() - $this->params->get( 'cacheTime', 86200 )) < filemtime( $cacheFilepath ) ){
					// cache ważne
					if($curlOutput = file_get_contents( $cacheFilepath )){
						$cacheExists = true;
					}else{
						$this->mark( 'Nie można odczytać pliku cache' );
					}
				}else{
					unlink($cacheFilepath);
				}
			}
		}else{
			$this->mark( 'Cache wyłączone' );
		}
		if( $cacheExists ){ // cache exists
			switch($this->mainparams['format']){
				case'json':$r = json_decode( $curlOutput, true );
					break;
				case'serialize':
				default:
					$r = unserialize( $curlOutput );
			}
			if(!is_array($r)){
				$this->mark( 'Plik cache ma niepoprawny format' );
				$cacheExists = false;
			}else{
				$this->mark( 'Pobrano cache:' . $cacheFilename );
			}
		}
		if( !$cacheExists ){ // no cache
			$curlHandle = curl_init();
			curl_setopt( $curlHandle, CURLOPT_URL, $clApiUrl );
			curl_setopt( $curlHandle, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt( $curlHandle, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT'] );
			curl_setopt( $curlHandle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt( $curlHandle, CURLOPT_TIMEOUT, $this->params->get('timeout',10) );
			curl_setopt( $curlHandle, CURLOPT_FAILONERROR, true);
			curl_setopt( $curlHandle, CURLOPT_POST, 1);
			curl_setopt( $curlHandle, CURLOPT_POSTFIELDS, http_build_query($params));

			$curlOutput = curl_exec($curlHandle);
			// echo '<pre>'.print_r(array($curlOutput,$params,$clApiUrl),true).'</pre>';die;
			// curl_close($curlHandle);
			
			switch( $this->mainparams['format'] ){
				case'json':$r = json_decode( $curlOutput, true );
					break;
				case'serialize':
				default:
					$r = unserialize( $curlOutput );
			}
			//sprawdzanie odpowiedzi
			if ( $curlOutput === false ) {
				if( $throwError ){
					global $wp_query;
					header("HTTP/1.0 404 Not Found");
					$wp_query->set_404();
					$this->error = 'Błąd połączenia';
					return'';
				}else{
					return'';
				}
			}else if( $r['odpowiedz'] == false && isset( $r['info'] ) ){
				if( $throwError ){
					global $wp_query;
					header("HTTP/1.0 404 Not Found");
					$wp_query->set_404();
					$this->error = 'Brak wyników: '.$r['info'];
					return'';
				}else{
					return'';
				}
			}
			// zapis cache
			if( $this->params->get( 'cacheTime', 86200 ) != -1 ){
				if( file_put_contents( $cacheFilepath , $curlOutput ) ){
					$this->mark( 'Zapis Cache' );
				}else{
					$this->mark( 'Błąd zapisu cache:' . $cacheFilepath );
				}
			}
			
			$this->mark( 'Api pobranie info:'. http_build_query( $params ) );
		}
		// echo '<pre>'.print_r(array($params,$r),true).'</pre>';die;
		$this->response = $r;
		return $r;
	}
	private function mark( $msg ){
		return;
	}
	
	protected function getExtensionVersion($extension){
		if( !function_exists('get_plugin_data') ){
			require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}
		$plugin = get_plugin_data( COMPERIA_PATH_PLUGIN .'/'. $extension . '.php', false, false );
		return $plugin['Version'];
	}
}