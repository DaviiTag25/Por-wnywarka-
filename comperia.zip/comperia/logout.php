<?php
session_start();
require_once 'includes/auth.php';

// Wyloguj użytkownika
logout();
?>
